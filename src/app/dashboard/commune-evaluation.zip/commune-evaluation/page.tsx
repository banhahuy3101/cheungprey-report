import Section1Democracy from "./components/Section1Democracy";
import Section2Security from "./components/Section2Security";
import Section3Services from "./components/Section3Services";
import Section4Economy from "./components/Section4Economy";
import Section5SocialProtection from "./components/Section5SocialProtection";
import Section6Democracy from "./components/Section6Democracy";
import type { EvaluationData } from "@/lib/evaluation-schema";
import Section7Governance from "./components/Section7Governance";

const sampleData: Partial<EvaluationData> = {
  province: "រាជធានីភ្នំពេញ",
  district: "ខណ្ឌដូនពេញ",
  commune: "សង្កាត់ផ្សារថ្មី",
};

export default function CommuneEvaluationPage() {
  return (
    <div className="bg-white p-8 rounded-lg shadow-sm border border-slate-200">
      <Section1Democracy data={sampleData} />
      <Section2Security data={sampleData} />
      <Section3Services data={sampleData} />
      <Section4Economy data={sampleData} />
      <Section5SocialProtection data={sampleData} />
      <Section6Democracy data={sampleData} />
      <Section7Governance data={sampleData} />
    </div>
  );
}