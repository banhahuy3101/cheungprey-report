import type { EvaluationData } from "@/lib/evaluation-schema";

const khmerDigits: Record<string, string> = {
  "0": "០",
  "1": "១",
  "2": "២",
  "3": "៣",
  "4": "៤",
  "5": "៥",
  "6": "៦",
  "7": "៧",
  "8": "៨",
  "9": "៩",
};

function toKhmerNum(value: string | undefined): string {
  return (value || ".........").replace(/\d/g, (d) => khmerDigits[d]);
}

interface Section4Props {
  data: Partial<EvaluationData>;
}

export default function Section4Economy({ data: d }: Section4Props) {
  return (
    <table className="w-full border-collapse border border-black border-t-0">

      <tbody><tr>
          <td className="border border-black border-t-0 w-20 p-1 text-center font-siemreap">
            ៤
          </td>
          <td className="border border-black border-t-0 p-3 font-siemreap" colSpan={2}>
            ជាឃុំ សង្កាត់ដែលមានការអភិវឌ្ឍសេដ្ឋកិច្ចមូលដ្ឋាន
            ដើម្បីលើកកម្ពស់ជីវភាពរស់នៅរបស់ប្រជាពលរដ្ឋ
          </td>
        </tr><tr>
          <td className="border border-black border-t-0 w-20 p-1 text-center font-siemreap">
            ៤.១
          </td>
          <td className="border border-black border-t-0 p-3 font-siemreap" colSpan={2}>
            ការលើកកម្ពស់របរ មុខរបរ និងវគ្គបណ្តុះបណ្តាលវិជ្ជាជីវៈដល់ប្រជាពលរដ្ឋ
          </td>
        </tr><tr>
          <td className="border border-black w-20 p-1 text-center font-siemreap align-top">
            ៤.១.១
          </td>
          <td className="border border-black font-siemreap">
            <ol className="pl-5 space-y-1">
              <li>
                ១. ចំនួនសហគ្រាសខ្នាតតូចដើម្បីជីវភាព និងកែច្នៃផលិតផលក្នុងឃុំ
                សង្កាត់ជាផ្លូវការ លក្ខណៈ គ្រួសារ ឬសហគមន៍ដែលបានបង្កើត
              </li>
              <li>
                ២. ចំនួនសហគ្រាសខ្នាតតូចដើម្បីជីវភាព និងកែច្នៃផលិតផលក្នុងឃុំ
                សង្កាត់ជាផ្លូវការ លក្ខណៈ គ្រួសារ ឬសហគមន៍ដែលទទួលបានចុះបញ្ជីដោយឃុំ
                សង្កាត់
              </li>
            </ol>
          </td>
          <td className="border border-black w-[40%] font-siemreap pr-4 text-justify align-top">
            <ol className="pl-5 space-y-1">
              <li>១. ចំនួន {toKhmerNum(d.smallBusinessesCount)} សហគ្រាស</li>
              <li>
                ២. ចំនួន {toKhmerNum(d.registeredSmallBusinesses)} សហគ្រាស
              </li>
            </ol>
          </td>
        </tr><tr>
          <td className="border border-black w-20 p-1 text-center font-siemreap align-top">
            ៤.១.២
          </td>
          <td className="border border-black p-3 font-siemreap">
            ការផ្សព្វផ្សាយព័ត៌មានគ្រប់គ្រងហិរញ្ញវត្ថុដល់ប្រជាពលរដ្ឋនៅក្នុងឃុំ
            សង្កាត់
          </td>
          <td className="border border-black w-[40%] pl-5 pr-4 font-siemreap text-justify align-top">
            <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
              <input
                type="checkbox"
                disabled
                className="accent-blue-600"
                checked={d.hasFinancialLiteracy === "បាន"}
              />
              បាន
            </label>
            <label className="inline-flex items-center gap-4 cursor-not-allowed">
              <input
                type="checkbox"
                disabled
                className="accent-blue-600"
                checked={d.hasFinancialLiteracy === "មិនបាន"}
              />
              មិនបាន
            </label>
          </td>
        </tr><tr>
          <td className="border border-black w-20 p-1 text-center font-siemreap align-top">
            ៤.១.៣
          </td>
          <td className="border border-black p-3 font-siemreap">
            ការបង្កើតយន្តការបណ្តុះបណ្តាលជំនាញដល់យុវជនក្នុងឃុំ សង្កាត់
          </td>
          <td className="border border-black w-[40%] pl-5 pr-4 font-siemreap text-justify align-top">
            <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
              <input
                type="checkbox"
                disabled
                className="accent-blue-600"
                checked={d.hasYouthSkillsTraining === "មាន"}
              />
              មាន
            </label>
            <label className="inline-flex items-center gap-4 cursor-not-allowed">
              <input
                type="checkbox"
                disabled
                className="accent-blue-600"
                checked={d.hasYouthSkillsTraining === "គ្មាន"}
              />
              គ្មាន
            </label>
          </td>
        </tr><tr>
          <td className="border border-black w-20 p-1 text-center font-siemreap align-top">
            ៤.១.៤
          </td>
          <td className="border border-black p-3 font-siemreap">
            ការបង្កើតផ្សារសហគមន៍ក្នុងឃុំ សង្កាត់
          </td>
          <td className="border border-black w-[40%] pl-5 pr-4 font-siemreap text-justify align-top">
            រួមមាន {toKhmerNum(d.hasCommunityMarket)}
          </td>
        </tr><tr>
          <td className="border border-black w-20 p-1 text-center font-siemreap align-top">
            ៤.៣.១
          </td>
          <td className="border border-black font-siemreap">
            <ol className="pl-5 space-y-1">
              <li>
                ១. ការផ្សព្វផ្សាយអំពីសារៈសំខាន់
                និងការចូលរួមរបស់ប្រជាពលរដ្ឋក្នុងការថែរក្សា ការពារ
                សម្បត្តិវប្បធម៌ បេតិកភណ្ឌជាតិ អត្តសញ្ញាណ និងប្រពៃណី
                ទំនៀមទម្លាប់ដ៏ថ្លៃថ្លារបស់ជាតិនៅក្នុងឃុំ សង្កាត់
              </li>
              <li>
                ២. ការបណ្តុះបណ្តាលអំពីជំនាញសិល្បៈ សិល្បៈស្មូន
                និងសិល្បៈកម្រដទៃទៀតរបស់ប្រជាជន នៅតាមមូលដ្ឋាន
                និងសហគមន៍ជនជាតិដើមភាគតិច
              </li>
            </ol>
          </td>
          <td className="border border-black w-[40%] font-siemreap pr-4 text-justify align-top">
            <ol className="pl-5 space-y-1">
              <li>
                ១.
                <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
                  <input
                    type="checkbox"
                    disabled
                    className="accent-blue-600"
                    checked={d.hasCulturalPromotion === "មាន"}
                  />
                  មាន
                </label>
                <label className="inline-flex items-center gap-4 cursor-not-allowed">
                  <input
                    type="checkbox"
                    disabled
                    className="accent-blue-600"
                    checked={d.hasCulturalPromotion === "មិនមាន"}
                  />
                  មិនមាន
                </label>
              </li>
              <li>
                ២.
                <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
                  <input
                    type="checkbox"
                    disabled
                    className="accent-blue-600"
                    checked={d.hasArtsTraining === "បាន"}
                  />
                  បាន
                </label>
                <label className="inline-flex items-center gap-4 cursor-not-allowed">
                  <input
                    type="checkbox"
                    disabled
                    className="accent-blue-600"
                    checked={d.hasArtsTraining === "មិនបាន"}
                  />
                  មិនបាន
                </label>
              </li>
            </ol>
          </td>
        </tr><tr>
          <td className="border border-black w-20 p-1 text-center font-siemreap align-top">
            ៤.៣.២
          </td>
          <td className="border border-black p-3 font-siemreap">
            ចំនួនករណីបទល្មើសធនធានធម្មជាតិដែលត្រូវបានទប់ស្កាត់ ឬបង្ក្រាប
          </td>
          <td className="border border-black w-[40%] pl-5 pr-4 font-siemreap text-justify align-top">
            ចំនួន {toKhmerNum(d.naturalResourceCrimeCases)} ករណី
          </td>
        </tr><tr>
          <td className="border border-black w-20 p-1 text-center font-siemreap align-top">
            ៤.៣.៤
          </td>
          <td className="border border-black p-3 font-siemreap">
            ឃុំ
            សង្កាត់បានបញ្ចូលគម្រោងការបង្កើតមុខរបរថ្មីៗសម្រាប់សហគមន៍តំបន់ការពារធម្មជាតិទៅក្នុងផែនការអភិវឌ្ឍន៍
            និងកម្មវិធីវិនិយោគបីឆ្នាំរំកិលឃុំ សង្កាត់
          </td>
          <td className="border border-black w-[40%] font-siemreap pr-4 text-justify align-top">
            <ol className="pl-5 space-y-1">
              <li>
                ១.
                <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
                  <input
                    type="checkbox"
                    disabled
                    className="accent-blue-600"
                    checked={d.hasNewMarketProjects === "មាន"}
                  />
                  មាន
                </label>
                <label className="inline-flex items-center gap-4 cursor-not-allowed">
                  <input
                    type="checkbox"
                    disabled
                    className="accent-blue-600"
                    checked={d.hasNewMarketProjects === "មិនមាន"}
                  />
                  មិនមាន
                </label>
              </li>
              <li>
                ២. ប្រសិនបើមាន មានមុខរបរអ្វីខ្លះ៖{" "}
                {toKhmerNum(d.newMarketDetails)}
              </li>
            </ol>
          </td>
        </tr><tr>
          <td className="border border-black w-20 p-1 text-center font-siemreap align-top">
            ៤.៣.៦
          </td>
          <td className="border border-black p-3 font-siemreap">
            ចំនួនសហគមន៍ទេសចរណ៍ មូលដ្ឋានដែលបានបង្កើតក្នុងឃុំ
            សង្កាត់ដែលមានតំបន់ទេសចរណ៍
          </td>
          <td className="border border-black w-[40%] pl-5 pr-4 font-siemreap text-justify align-top">
            ចំនួន {toKhmerNum(d.tourismCommunities)} សហគមន៍
          </td>
        </tr><tr>
          <td className="border border-black border-t-0 w-20 p-1 text-center font-siemreap">
            ៤.៤
          </td>
          <td className="border border-black border-t-0 p-3 font-siemreap" colSpan={2}>
            ការអភិវឌ្ឍ និងគ្រប់គ្រងផ្សារ
          </td>
        </tr><tr>
          <td className="border border-black w-20 p-1 text-center font-siemreap align-top">
            ៤.៤.២
          </td>
          <td className="border border-black p-3 font-siemreap">
            ចំនួនផ្សារដែលបានសាងសង់ កែលម្អ ឬរៀបចំឡើងវិញដែលបានដំណើរការ
            និងមានលក្ខណៈសមស្របនៅក្នុងឃុំ សង្កាត់
          </td>
          <td className="border border-black w-[40%] pl-5 pr-4 font-siemreap text-justify align-top">
            ចំនួន {toKhmerNum(d.marketCount)} ផ្សារ
          </td>
        </tr><tr>
          <td className="border border-black w-20 p-1 text-center font-siemreap align-top">
            ៤.៤.៣
          </td>
          <td className="border border-black font-siemreap">
            <ol className="pl-5 space-y-1">
              <li>១. ចំនួនផ្សារដែលមានគណៈកម្មការគ្រប់គ្រង</li>
              <li>
                ២. ការគ្រប់គ្រងផ្សារនៅតាមមូលដ្ឋានឃុំ សង្កាត់ឱ្យមានសុវត្ថិភាព
                សណ្តាប់ធ្នាប់ អនាម័យ និងបរិស្ថានល្អ
              </li>
            </ol>
          </td>
          <td className="border border-black w-[40%] font-siemreap pr-4 text-justify align-top">
            <ol className="pl-5 space-y-1">
              <li>១. ចំនួន {toKhmerNum(d.hasMarketManagement)} ផ្សារ</li>
              <li>
                ២.
                <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
                  <input
                    type="checkbox"
                    disabled
                    className="accent-blue-600"
                    checked={d.marketManagementQuality === "ល្អ"}
                  />
                  ល្អ
                </label>
                <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
                  <input
                    type="checkbox"
                    disabled
                    className="accent-blue-600"
                    checked={d.marketManagementQuality === "មធ្យម"}
                  />
                  មធ្យម
                </label>
                <label className="inline-flex items-center gap-4 cursor-not-allowed">
                  <input
                    type="checkbox"
                    disabled
                    className="accent-blue-600"
                    checked={d.marketManagementQuality === "មិនទាន់បានល្អ"}
                  />
                  មិនទាន់បានល្អ
                </label>
              </li>
            </ol>
          </td>
        </tr><tr>
          <td className="border border-black border-t-0 w-20 p-1 text-center font-siemreap">
            ៤.៥
          </td>
          <td className="border border-black border-t-0 p-3 font-siemreap" colSpan={2}>
            ការអភិវឌ្ឍសេដ្ឋកិច្ចមូលដ្ឋាននៅតាមតំបន់ព្រំដែន
          </td>
        </tr><tr>
          <td className="border border-black w-20 p-1 text-center font-siemreap align-top">
            ៤.៥.១
          </td>
          <td className="border border-black font-siemreap">
            <ol className="pl-5 space-y-1">
              <li>
                ចំនួនគម្រោងហេដ្ឋារចនាសម្ព័ន្ធដែលបានសាងសង់ ឬកែលម្អនៅតំបន់ព្រំដែន
                (គម្រោងហេដ្ឋារចនាសម្ព័ន្ធអ្វីខ្លះ?) *(បំពេញដោយឃុំ សង្កាត់ដែលនៅជាប់ព្រំដែន)*
              </li>
            </ol>
          </td>
          <td className="border border-black w-[40%] font-siemreap pr-4 text-justify align-top">
            ចំនួន {toKhmerNum(d.borderAreaInfrastructureProjects)} គម្រោង រួមមាន៖
            <div className="mt-2 whitespace-pre-line min-h-[3rem]">
              {toKhmerNum(d.borderAreaInfrastructureDetails)}
            </div>
          </td>
        </tr><tr>
          <td className="border border-black border-t-0 w-20 p-1 text-center font-siemreap">
            ៤.៦
          </td>
          <td className="border border-black border-t-0 p-3 font-siemreap" colSpan={2}>
            ការលើកកម្ពស់ភាពជាដៃគូផ្សារភ្ជាប់ជាមួយសហគមន៍មូលដ្ឋាន អង្គការសង្គមស៊ីវិល និងផ្នែកឯកជន
          </td>
        </tr></tbody>
    </table>
  );
}