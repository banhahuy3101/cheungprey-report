import Header from "./Header";
import type { EvaluationData } from "@/lib/evaluation-schema";
import { defaultEvaluationData } from "@/lib/evaluation-schema";

const khmerDigits: Record<string, string> = {
  "0": "០", "1": "១", "2": "២", "3": "៣", "4": "៤",
  "5": "៥", "6": "៦", "7": "៧", "8": "៨", "9": "៩",
};

function toKhmerNum(value: string): string {
  return value.replace(/\d/g, (d) => khmerDigits[d]);
}

interface AnnualReportTableProps {
  data?: Partial<EvaluationData>;
}

export default function AnnualReportTable({
  data = {},
}: AnnualReportTableProps) {
  const d: EvaluationData = { ...defaultEvaluationData, ...data };

  return (
    <div className="max-w-7xl mx-auto text-black">
      <Header province={d.province} district={d.district} commune={d.commune} />

      <table className="w-full border-collapse border border-black mt-10">
        <thead>
          <tr>
            <th className="border border-black w-20 p-1 text-center font-moul">
              ល.រ
            </th>
            <th className="border border-black p-1 font-moul">សូចនាករ</th>
            <th className="border border-black w-[40%] p-1 font-moul">
              <div className="text-wrap font-moul text-xs">
                ទិន្នន័យ ឬព័ត៌មាន លទ្ធផលនៃការអនុវត្ត
              </div>
              <div className="mt-2 text-red-600 font-moul">
                (សម្គាល់៖ ទិន្នន័យលទ្ធផលនេះ
                គិតចាប់ពីដើមឆ្នាំ២០២២ ដល់ខែមិថុនា ឆ្នាំ២០២៦)
              </div>
            </th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td className="border border-black text-center p-3 font-siemreap">
              ១
            </td>
            <td className="border border-black p-3 font-siemreap" colSpan={2}>
              ជាឃុំ សង្កាត់ដែលលើកកម្ពស់លទ្ធិប្រជាធិបតេយ្យនៅមូលដ្ឋាន និងសិទ្ធិសេរីភាពរបស់ប្រជាជនគ្រប់រូប ប្រជាជនរស់នៅដោយសុខដុមរមនា
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center p-3 font-siemreap">
              ១.១
            </td>
            <td className="border border-black p-3 font-siemreap" colSpan={2}>
              ការលើកកម្ពស់លទ្ធិប្រជាធិបតេយ្យនៅមូលដ្ឋាន
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ១.១.២
            </td>
            <td className="border border-black font-siemreap">
              <ol className="pl-5 space-y-1">
                <li>១. ភាគរយចំនួនប្រជាពលរដ្ឋគ្រប់អាយុ១៨ឆ្នាំ ទៅចុះឈ្មោះបោះឆ្នោតតំណាងរាស្ត្រ</li>
                <li>២. ភាគរយចំនួនប្រជាពលរដ្ឋគ្រប់អាយុ១៨ឆ្នាំ ទៅចុះឈ្មោះបោះឆ្នោតឃុំ សង្កាត់</li>
                <li>៣. ភាគរយនៃចំនួនប្រជាពលរដ្ឋមានឈ្មោះបោះឆ្នោតបានទៅបោះឆ្នោតតំណាងរាស្ត្រ</li>
                <li>៤. ភាគរយនៃចំនួនប្រជាពលរដ្ឋមានឈ្មោះបោះឆ្នោតបានទៅបោះឆ្នោតឃុំ សង្កាត់</li>
                <li>៥. ករណីអំពើហិង្សាពាក់ព័ន្ធនឹងការបោះឆ្នោតតំណាងរាស្ត្រឆ្នាំ២០២៣</li>
                <li>៦. ករណីអំពើហិង្សាពាក់ព័ន្ធនឹងការបោះឆ្នោតឃុំ សង្កាត់២០២២</li>
              </ol>
            </td>
            <td className="border border-black font-siemreap pr-4 text-justify align-top">
              <ol className="pl-5 space-y-1 text-wrap">
                <li>១. ចំនួន {toKhmerNum(d.registeredVotersNational2023)}% ប្រជាពលរដ្ឋគ្រប់អាយុ១៨ឆ្នាំ ទៅចុះឈ្មោះបោះឆ្នោតតំណាងរាស្ត្រ២០២៣</li>
                <li>២. ចំនួន {toKhmerNum(d.registeredVotersCommune2022)}% ប្រជាពលរដ្ឋគ្រប់អាយុ១៨ឆ្នាំ ទៅចុះឈ្មោះបោះឆ្នោតឃុំ សង្កាត់២០២២</li>
                <li>៣. ចំនួន {toKhmerNum(d.voterTurnoutNational2023)}% ប្រជាពលរដ្ឋមានឈ្មោះបោះឆ្នោតបានទៅបោះឆ្នោតតំណាងរាស្ត្រ២០២៣</li>
                <li>៤. ចំនួន {toKhmerNum(d.voterTurnoutCommune2022)} ប្រជាពលរដ្ឋមានឈ្មោះបោះឆ្នោតបានទៅបោះឆ្នោតឃុំ សង្កាត់២០២២</li>
                <li>៥. ចំនួន {toKhmerNum(d.violenceCasesNational2023)} ករណីពាក់ព័ន្ធនឹងការបោះឆ្នោតតំណាងរាស្ត្រ២០២៣</li>
                <li>៦. ចំនួន {toKhmerNum(d.violenceCasesCommune2022)} ករណីពាក់ព័ន្ធនឹងការបោះឆ្នោតបោះឆ្នោតឃុំ សង្កាត់២០២២</li>
              </ol>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ១.១.៣
            </td>
            <td className="border border-black font-siemreap">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួនសមាជិកក្រុមប្រឹក្សាឃុំ សង្កាត់មានសញ្ញាបត្រមធ្យមសិក្សាទុតិយភូមិ បរិញ្ញាបត្ររង បរិញ្ញាបត្រ បរិញ្ញាបត្រជាន់ខ្ពស់</li>
                <li>២. ចំនួនសមាជិកក្រុមប្រឹក្សាឃុំ សង្កាត់ដែលត្រូវដកចេញពីមុខតំណែងដោយសារ ឬ ទទួលទណ្ឌកម្មវិន័យពាក់ព័ន្ធអាប្បកិរិយា មិនស្អាតស្អំ ការមិនគោរពច្បាប់ ការរើសអើង</li>
              </ol>
            </td>
            <td className="border border-black font-siemreap pr-4 text-justify align-top">
              <ol className="pl-5 space-y-1">
                <li>១.១. ចំនួនសមាជិកក្រុមប្រឹក្សាឃុំ សង្កាត់មានសញ្ញាបត្រមធ្យមសិក្សាទុតិយភូមិ {toKhmerNum(d.highSchoolDiploma)} នាក់</li>
                <li>១.២. ចំនួនសមាជិកក្រុមប្រឹក្សាឃុំ សង្កាត់មានបរិញ្ញាបត្ររង {toKhmerNum(d.associateDegree)} នាក់</li>
                <li>១.៣. ចំនួនសមាជិកក្រុមប្រឹក្សាឃុំ សង្កាត់មានបរិញ្ញាបត្រ {toKhmerNum(d.bachelorDegree)} នាក់</li>
                <li>១.៤. ចំនួនសមាជិកក្រុមប្រឹក្សាឃុំ សង្កាត់មានបរិញ្ញាបត្រជាន់ខ្ពស់ឡើង {toKhmerNum(d.masterDegree)} នាក់</li>
                <li>២. ចំនួនសមាជិកក្រុមប្រឹក្សាឃុំ សង្កាត់ដែលត្រូវដកចេញពីមុខតំណែងដោយសារ ឬ ទទួលទណ្ឌកម្មវិន័យពាក់ព័ន្ធអាប្បកិរិយា មិនស្អាតស្អំ ការមិនគោរពច្បាប់ ការរើសអើង {toKhmerNum(d.removedCouncilMembers)} នាក់</li>
              </ol>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ១.១.៤
            </td>
            <td className="border border-black font-siemreap">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួនសមាជិកក្រុមប្រឹក្សាឃុំ សង្កាត់មានសញ្ញាបត្រមធ្យមសិក្សាទុតិយភូមិ បរិញ្ញាបត្ររង បរិញ្ញាបត្រ បរិញ្ញាបត្រជាន់ខ្ពស់</li>
              </ol>
            </td>
            <td className="border border-black font-siemreap pr-4 text-justify align-top">
              <ol className="pl-5 space-y-1">
                <li>១.១. ចំនួនសរុបនៃសមាជិកក្រុមប្រឹក្សាឃុំ សង្កាត់ {toKhmerNum(d.totalCouncilMembers)}</li>
                <li>១.២. ចំនួនសមាជិកក្រុមប្រឹក្សាឃុំ សង្កាត់ជាស្រ្តី {toKhmerNum(d.femaleCouncilMembers)}</li>
                <li>១.៣. ចំនួនសមាជិកក្រុមប្រឹក្សាឃុំ សង្កាត់ជាយុវជន (ក្រោម៣៥ឆ្នាំ) {toKhmerNum(d.youthCouncilMembers)}</li>
                <li>១.៤. ចំនួនសរុបស្មៀនឃុំ សង្កាត់ {toKhmerNum(d.totalClerks)} នាក់</li>
                <li>១.៥. ចំនួនសរុបស្មៀនឃុំ សង្កាត់ជាស្រ្តី {toKhmerNum(d.femaleClerks)} នាក់</li>
                <li>១.៦. ចំនួនសរុបស្មៀនឃុំ សង្កាត់ជាយុវជន (ក្រោម៣៥ឆ្នាំ) {toKhmerNum(d.youthClerks)} នាក់</li>
                <li>១.៧. ចំនួនសរុបថ្នាក់ដឹកនាំភូមិ {toKhmerNum(d.totalVillageLeaders)} នាក់</li>
                <li>១.៨. ចំនួនថ្នាក់ដឹកនាំភូមិជាស្រ្តី {toKhmerNum(d.femaleVillageLeaders)} នាក់</li>
                <li>១.៩. ចំនួនថ្នាក់ដឹកនាំភូមិជាយុវជន (ក្រោម៣៥ឆ្នាំ) {toKhmerNum(d.youthVillageLeaders)} នាក់</li>
              </ol>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center p-3 font-siemreap">
              ១.២
            </td>
            <td className="border border-black p-3 font-siemreap" colSpan={2}>
              ការលើកកម្ពស់សិទ្ធិសេរីភាពរបស់ប្រជាពលរដ្ឋ
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ១.២.១
            </td>
            <td className="border border-black p-3 font-siemreap">
              ករណីរំលោភសិទ្ធិ ជំនឿសាសនា សិទ្ធិមនុស្សពាក់ព័ន្ធនឹងការប្រកាន់ពូជសាសន៍ ពណ៌សម្បុរ ភេទ ភាសា និន្នាការនយោបាយ អតីតកាល ដើមកំណើតជាតិ ឋានៈសង្គម ធនធាន ឬស្ថានភាពផ្សេងទៀត
            </td>
            <td className="border border-black p-3 font-siemreap text-justify">
              ចំនួនករណីរំលោភសិទ្ធិមនុស្សពាក់ព័ន្ធនឹងការប្រកាន់ពូជសាសន៍ ពណ៌សម្បុរ ភេទ ភាសា ជំនឿ សាសនា និន្នាការនយោបាយ អតីតកាល ដើមកំណើតជាតិ ឋានៈសង្គម ធនធាន ឬ ស្ថានភាពផ្សេងទៀត {toKhmerNum(d.humanRightsViolations)}
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ១.២.២
            </td>
            <td className="border border-black p-3 font-siemreap">
              ចំនួនប្រជាពលរដ្ឋ ដែលបានចូលរួមវេទិកាសាធារណៈរបស់ឃុំ សង្កាត់
            </td>
            <td className="border border-black p-3 font-siemreap text-justify">
              ចំនួនប្រជាពលរដ្ឋដែលបានចូលរួមវេទិកាសាធារណៈរបស់ឃុំ សង្កាត់ {toKhmerNum(d.publicForumParticipants)} នាក់
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ១.២.៣
            </td>
            <td className="border border-black font-siemreap">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួនប្រជាពលរដ្ឋ ដែលបានចូលរួមកិច្ចប្រជុំក្រុមប្រឹក្សាឃុំ សង្កាត់</li>
                <li>២. ចំនួនប្រជាពលរដ្ឋចូលរួម ក្នុងដំណើរការរៀបចំផែនការអភិវឌ្ឍ និងកម្មវិធីវិនិយោគ ៣ឆ្នាំរំកិលរបស់ឃុំ សង្កាត់</li>
                <li>៣. ឃុំ សង្កាត់ដែលបានបង្កើតគណៈកម្មការគ្រប់គ្រងគម្រោងដែលមានការចូលរួមពីប្រជាពលរដ្ឋ (មាន ឬមិនមាន)</li>
              </ol>
            </td>
            <td className="border border-black font-siemreap pr-4 text-justify align-top">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួន {toKhmerNum(d.councilMeetingParticipants)} នាក់</li>
                <li>២. ចំនួន {toKhmerNum(d.planningProcessParticipants)} នាក់</li>
                <li>៣. 
                  <label className="pl-5 inline-flex items-center gap-4 mr-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.hasProjectManagementCommittee === "មាន"} />
                    មាន
                  </label>
                  <label className="inline-flex items-center gap-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.hasProjectManagementCommittee === "មិនមាន"} />
                    មិនមាន
                  </label>
                </li>
              </ol>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ១.២.៤
            </td>
            <td className="border border-black font-siemreap">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួនប្រជាពលរដ្ឋដែលបានទទួលសេវារដ្ឋបាល ឃុំ សង្កាត់</li>
                <li>២. ចំនួនគម្រោង (សេវាសង្គម និងហេដ្ឋារចនាសម្ព័ន្ធ) បានរៀបចំដោយឃុំ សង្កាត់</li>
              </ol>
            </td>
            <td className="border border-black font-siemreap pr-4 text-justify align-top">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួន {toKhmerNum(d.administrativeServiceRecipients)} នាក់</li>
                <li>២. ចំនួន {toKhmerNum(d.communityProjectsCount)} គម្រោង</li>
              </ol>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ១.២.៥
            </td>
            <td className="border border-black font-siemreap">
              <ol className="pl-5 space-y-1">
                <li>១. សំណើ សំណូមពរ ក្តីកង្វល់ និងបញ្ហាប្រឈមនានារបស់ប្រជាពលរដ្ឋពាក់ព័ន្ធនឹងការផ្តល់សេវា</li>
                <li>២. ការសម្របសម្រួលដោះស្រាយសំណើ សំណូមពរ ក្តីកង្វល់ និងបញ្ហាប្រឈមនានា</li>
              </ol>
            </td>
            <td className="border border-black font-siemreap pr-4 text-justify align-top">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួន {toKhmerNum(d.serviceRequestCases)} ករណី</li>
                <li>២. ចំនួន {toKhmerNum(d.serviceResolvedCases)} ករណី</li>
              </ol>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ១.៣
            </td>
            <td colSpan={2} className="border border-black p-3 font-siemreap">
              ភាពសុខដុមរមនាក្នុងសង្គម
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ១.៣.១
            </td>
            <td className="border border-black font-siemreap">
              <ol className="pl-5 space-y-1">
                <li>១. វិវាទពាក់ព័ន្ធនឹងជំនឿ ប្រពៃណី និងសាសនាផ្សេងៗគ្នានៅមូលដ្ឋាន</li>
              </ol>
            </td>
            <td className="border border-black font-siemreap pr-4 text-justify align-top">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួន {toKhmerNum(d.religiousDisputeCases)} ករណី</li>
              </ol>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ១.៣.២
            </td>
            <td className="border border-black font-siemreap">
              <ol className="pl-5 space-y-1">
                <li>១. ករណីវិវាទរវាងប្រជាពលរដ្ឋនិងប្រជាពលរដ្ឋពាក់ព័ន្ធនឹងនិន្នាការនយោបាយ</li>
              </ol>
            </td>
            <td className="border border-black font-siemreap pr-4 text-justify align-top">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួន {toKhmerNum(d.politicalDisputeCases)} ករណី</li>
              </ol>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ១.៣.៣
            </td>
            <td className="border border-black font-siemreap p-3">
              ឃុំ សង្កាត់ដែលមានមណ្ឌល ទីធ្លាសាធារណៈ ឬអគារវប្បធម៌ក្នុងសហគមន៍ដែលសាធារណជនអាចមានការជួបជុំ ការសម្តែង និងការចែករំលែកនូវសិល្បៈ ប្រពៃណី ទំនៀមទម្លាប់ សាសនា និងចំណេះដឹងផ្សេងៗ
            </td>
            <td className="border border-black pl-5 pr-4 font-siemreap text-justify align-top">
              <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
                <input type="checkbox" disabled className="accent-blue-600" checked={d.hasCommunityCulturalSpace === "មាន"} />
                មាន
              </label>
              <label className="inline-flex items-center gap-4 cursor-not-allowed">
                <input type="checkbox" disabled className="accent-blue-600" checked={d.hasCommunityCulturalSpace === "មិនមាន"} />
                មិនមាន
              </label>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center p-3 font-siemreap">
              ២
            </td>
            <td className="border border-black p-3 font-siemreap" colSpan={2}>
              ជាឃុំ សង្កាត់ដែលមានសន្តិសុខ របៀបរៀបរយ សណ្តាប់ធ្នាប់សាធារណៈ និងសុវត្ថិភាពសង្គមល្អប្រសើរ
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center p-3 font-siemreap">
              ២.១
            </td>
            <td className="border border-black p-3 font-siemreap" colSpan={2}>
              គ្មានបទល្មើសលួច ឆក់ ប្លន់ គ្រឿងញៀន ល្បែងស៊ីសងខុសច្បាប់ និងបទល្មើសផ្សេងៗទៀតក្នុងភូមិ ឃុំ សង្កាត់
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ២.១.៣
            </td>
            <td className="border border-black font-siemreap p-3">
              ចំនួនប្រជាការពារនៅតាមឃុំ សង្កាត់
            </td>
            <td className="border border-black pl-5 pr-4 font-siemreap text-justify align-top">
              ចំនួន {toKhmerNum(d.communeGuardCount)} នាក់
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ២.១.៤
            </td>
            <td className="border border-black font-siemreap">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួនវគ្គបណ្តុះបណ្តាល និងពង្រឹងសមត្ថភាពប្រជាការពារ</li>
                <li>២. ការគាំទ្រផ្សេងៗដល់ប្រជាការពារ</li>
              </ol>
            </td>
            <td className="border border-black font-siemreap pr-4 text-justify align-top">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួន {toKhmerNum(d.communeGuardTrainingCount)} វគ្គបណ្តុះបណ្តាល និងពង្រឹងសមត្ថភាពប្រជាការពារ</li>
                <li>២. ការគាំទ្រផ្សេងៗដល់ប្រជាការពារ រួមមាន {toKhmerNum(d.communeGuardSupport)}</li>
              </ol>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ២.១.៥
            </td>
            <td className="border border-black font-siemreap">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួនមន្ត្រីនគរបាលរដ្ឋបាលនៅឃុំ សង្កាត់នីមួយៗ</li>
                <li>២. ចំនួនវគ្គបណ្តុះបណ្តាលដែលផ្តល់ឱ្យប៉ុស្តិ៍នគរបាលរដ្ឋបាលឃុំ សង្កាត់</li>
                <li>៣. ការគាំទ្រផ្សេងៗដល់ប៉ុស្តិ៍នគរបាល</li>
              </ol>
            </td>
            <td className="border border-black font-siemreap pr-4 text-justify align-top">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួន {toKhmerNum(d.administrativePoliceCount)} នាក់</li>
                <li>២. ចំនួន {toKhmerNum(d.policeTrainingCount)} វគ្គ</li>
                <li>៣. រួមមាន {toKhmerNum(d.policeSupport)}</li>
              </ol>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ២.១.៦
            </td>
            <td className="border border-black font-siemreap p-3">
              អត្រាបទល្មើសដែលបង្ក្រាបបាន បើប្រៀបធៀបនឹងបទល្មើសដែលកើតឡើង
            </td>
            <td className="border border-black pl-5 pr-4 font-siemreap text-justify align-top">
              ចំនួន {toKhmerNum(d.crimeSuppressionRate)} %
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ២.១.៧
            </td>
            <td className="border border-black font-siemreap">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួនកម្មវិធីអប់រំ និងផ្សព្វផ្សាយអំពីបញ្ហាបទល្មើស រៀបចំនៅតាមមូលដ្ឋាន តាមវត្តអារាម សាលារៀន និងទីតាំងនានា និងគ្រឿងញៀនដែលបាន</li>
                <li>២. ចំនួនប្រជាពលរដ្ឋចូលរួមកម្មវិធីអប់រំ និងផ្សព្វផ្សាយអំពីបញ្ហាបទល្មើស និងគ្រឿងញៀនដែលបានរៀបចំនៅតាមមូលដ្ឋាន តាមសាលារៀន និងទីតាំងនានា</li>
              </ol>
            </td>
            <td className="border border-black font-siemreap pr-4 text-justify align-top">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួន {toKhmerNum(d.crimeEducationPrograms)} កម្មវិធី</li>
                <li>២. ចំនួន {toKhmerNum(d.crimeEducationParticipants)} នាក់</li>
              </ol>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center p-3 font-siemreap">
              ២.២
            </td>
            <td className="border border-black p-3 font-siemreap" colSpan={2}>
              មានសណ្តាប់ធ្នាប់សាធារណៈល្អ ជាពិសេសគ្មានគ្រោះថ្នាក់ចរាចរណ៍
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ២.២.១
            </td>
            <td className="border border-black font-siemreap">
              <ol className="pl-5 space-y-1">
                <li>១. ឃុំ សង្កាត់ដែលរៀបចំឱ្យមានការសម្រួលចរាចរណ៍ ឆ្លងកាត់ផ្លូវសាធារណៈរបស់ប្រជាពលរដ្ឋ ជាពិសេសសិស្សានុសិស្ស</li>
                <li>២. ចំនួនស្លាកសញ្ញាចរាចរណ៍នៅក្នុងឃុំ សង្កាត់ (គ្រប់គ្រាន់ ឬមិនទាន់គ្រប់គ្រាន់ ឬគ្មាន)</li>
                <li>៣. ចំនួនគ្រោះថ្នាក់ចរាចរណ៍</li>
              </ol>
            </td>
            <td className="border border-black font-siemreap pr-4 text-justify align-top">
              <ol className="pl-5 space-y-1">
                <li>១. 
                  <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.hasTrafficManagement === "មាន"} />
                    មាន
                  </label>
                  <label className="inline-flex items-center gap-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.hasTrafficManagement === "គ្មាន"} />
                    គ្មាន
                  </label>
                </li>
                <li>២. 
                  <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.trafficSignsStatus === "គ្រប់គ្រាន់"} />
                    គ្រប់គ្រាន់
                  </label>
                  <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.trafficSignsStatus === "មិនទាន់គ្រប់គ្រាន់"} />
                    មិនទាន់គ្រប់គ្រាន់
                  </label>
                  <label className="inline-flex items-center gap-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.trafficSignsStatus === "គ្មាន"} />
                    គ្មាន
                  </label>
                </li>
                <li>៣. ចំនួន {toKhmerNum(d.trafficAccidentCases)} ករណី</li>
              </ol>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ២.២.២
            </td>
            <td className="border border-black font-siemreap">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួនទីប្រជុំជន សាលារៀន តំបន់ជុំវិញផ្សារ និងតំបន់ស្មុគស្មាញនានា ដែលមានសណ្តាប់ធ្នាប់ល្អ</li>
                <li>២. ចំនួនទីប្រជុំជន សាលារៀន តំបន់ជុំវិញផ្សារ និងតំបន់ស្មុគស្មាញនានាដែលមិនទាន់មានសណ្តាប់ធ្នាប់ល្អ</li>
              </ol>
            </td>
            <td className="border border-black font-siemreap pr-4 text-justify align-top">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួន {toKhmerNum(d.orderlyPlaces)} កន្លែង</li>
                <li>២. ចំនួន {toKhmerNum(d.disorderlyPlaces)} កន្លែង</li>
              </ol>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ២.២.៣
            </td>
            <td className="border border-black font-siemreap p-3">
              ឃុំ សង្កាត់ដែលមានចំណតសាធារណៈ
            </td>
            <td className="border border-black pl-5 pr-4 font-siemreap text-justify align-top">
              <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
                <input type="checkbox" disabled className="accent-blue-600" checked={d.hasPublicParking === "មាន"} />
                មាន
              </label>
              <label className="inline-flex items-center gap-4 cursor-not-allowed">
                <input type="checkbox" disabled className="accent-blue-600" checked={d.hasPublicParking === "គ្មាន"} />
                គ្មាន
              </label>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ២.២.៤
            </td>
            <td className="border border-black font-siemreap">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួនកម្មវិធីផ្សព្វផ្សាយ និងអប់រំច្បាប់ចរាចរណ៍</li>
                <li>២. ចំនួនប្រជាពលរដ្ឋដែលបានចូលរួមអប់រំផ្សព្វផ្សាយច្បាប់ចរាចរណ៍</li>
              </ol>
            </td>
            <td className="border border-black font-siemreap pr-4 text-justify align-top">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួន {toKhmerNum(d.trafficLawEducationSessions)} វគ្គ</li>
                <li>២. ចំនួន {toKhmerNum(d.trafficLawEducationParticipants)} នាក់</li>
              </ol>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center p-3 font-siemreap">
              ២.៣
            </td>
            <td className="border border-black p-3 font-siemreap" colSpan={2}>
              គ្មានអំពើអនាចារ គ្មានការជួញដូរមនុស្ស ជាពិសេសស្ត្រីនិងកុមារ គ្មានអំពើហិង្សាក្នុងគ្រួសារ និងគ្មានក្មេងទំនើង
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center p-3 font-siemreap">
              ៣
            </td>
            <td className="border border-black p-3 font-siemreap" colSpan={2}>
              ជាឃុំ សង្កាត់ដែលមានការផ្តល់សេវាសាធារណៈជូនប្រជាពលរដ្ឋប្រកបដោយគុណភាព តម្លាភាព គណនេយ្យភាព និងជឿទុកចិត្ត
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center p-3 font-siemreap">
              ៣.១
            </td>
            <td className="border border-black p-3 font-siemreap" colSpan={2}>
              សេវារដ្ឋបាល
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៣.១.១
            </td>
            <td className="border border-black p-3 font-siemreap">
              ចំនួនប្រជាពលរដ្ឋដែលបានទទួលសេវារដ្ឋបាលនៅឃុំ សង្កាត់
            </td>
            <td className="border border-black pl-5 pr-4 font-siemreap text-justify align-top">
              ចំនួន {toKhmerNum(d.serviceRecipientsCount)} នាក់
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៣.១.២
            </td>
            <td className="border border-black font-siemreap">
              ចំនួនសេវារដ្ឋបាលដែលបានផ្តល់ជូនប្រជាពលរដ្ឋ តាមប្រភេទនីមួយៗ ៖
              <ol className="pl-5 space-y-1 mt-1">
                <li>១. ចំនួនបញ្ជីកំណើត</li>
                <li>២. ចំនួនបញ្ជីអាពាហ៍ពិពាហ៍</li>
                <li>៣. ចំនួនបញ្ជីមរណភាព</li>
                <li>៤. ចំនួនការផ្តល់សៀវភៅស្នាក់នៅ សៀវភៅគ្រួសារ</li>
                <li>៥. ចំនួនអត្តសញ្ញាណប័ណ្ណសញ្ជាតិខ្មែរ</li>
              </ol>
            </td>
            <td className="border border-black font-siemreap pr-4 text-justify align-top">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួន {toKhmerNum(d.birthRegistrations)} សេវា</li>
                <li>២. ចំនួន {toKhmerNum(d.marriageRegistrations)} សេវា</li>
                <li>៣. ចំនួន {toKhmerNum(d.deathRegistrations)} សេវា</li>
                <li>៤. ចំនួន {toKhmerNum(d.residenceBookIssued)} សេវា</li>
                <li>៥. ចំនួន {toKhmerNum(d.identityCardsIssued)} សេវា</li>
              </ol>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៣.១.៤
            </td>
            <td className="border border-black font-siemreap p-3">
              មធ្យោបាយទទួលមតិរិះគន់ ឬសំណូមពរជូនប្រជាពលរដ្ឋដែលឃុំ សង្កាត់កំពុងអនុវត្ត រួមមាន (ប្រអប់សំបុត្រ តេឡេក្រាម បណ្តាញទំនាក់ទំនងសង្គម។ល។)
            </td>
            <td className="border border-black pl-5 pr-4 font-siemreap text-justify align-top">
              រួមមាន {toKhmerNum(d.feedbackMethods)}
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center p-3 font-siemreap">
              ៣.២
            </td>
            <td className="border border-black p-3 font-siemreap" colSpan={2}>
              សេវាអប់រំ
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៣.២.៥
            </td>
            <td className="border border-black font-siemreap">
              <ol className="pl-5 space-y-1">
                <li>១. សមាជិកក្រុមប្រឹក្សាឃុំ សង្កាត់ជាសមាជិកគណៈកម្មាធិការគ្រប់គ្រងសាលារៀន</li>
                <li>២. សមាជិកក្រុមប្រឹក្សាក្រុង ស្រុក ខណ្ឌ ជាសមាជិកគណៈកម្មាធិការគ្រប់គ្រងសាលារៀន</li>
                <li>៣. ចំនួនកិច្ចប្រជុំប្រចាំខែរបស់គណៈកម្មាធិការគ្រប់គ្រងសាលារៀន</li>
              </ol>
            </td>
            <td className="border border-black font-siemreap pr-4 text-justify align-top">
              <ol className="pl-5 space-y-1">
                <li>១. 
                  <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.hasCouncilMemberSchoolCommittee === "មាន"} />
                    មាន
                  </label>
                  <label className="inline-flex items-center gap-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.hasCouncilMemberSchoolCommittee === "គ្មាន"} />
                    គ្មាន
                  </label>
                </li>
                <li>២. 
                  <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.hasDistrictMemberSchoolCommittee === "មាន"} />
                    មាន
                  </label>
                  <label className="inline-flex items-center gap-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.hasDistrictMemberSchoolCommittee === "គ្មាន"} />
                    គ្មាន
                  </label>
                </li>
                <li>៣. ចំនួន {toKhmerNum(d.schoolMeetingCount)} ដង</li>
              </ol>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៣.២.៦
            </td>
            <td className="border border-black font-siemreap">
              <ol className="pl-5 space-y-1">
                <li>១. គ្រូបង្រៀននៅតាមតំបន់ដាច់ស្រយាល និងតំបន់ជួបការលំបាក ត្រូវបានគាំទ្រ និងលើកទឹកចិត្ត (មាន ឬគ្មាន) តាមរយៈការផ្តល់ប្រាក់ឧបត្ថម្ភបន្ថែម ឬផ្សេងទៀត</li>
                <li>២. បើមាន សូមរៀបរាប់ការគាំទ្រគ្រូបង្រៀននៅតាមតំបន់ដាច់ស្រយាល និងតំបន់ជួបការលំបាកទាំងនោះ</li>
              </ol>
            </td>
            <td className="border border-black font-siemreap pr-4 text-justify align-top">
              <ol className="pl-5 space-y-1">
                <li>១. 
                  <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.hasTeacherSupport === "មាន"} />
                    មាន
                  </label>
                  <label className="inline-flex items-center gap-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.hasTeacherSupport === "គ្មាន"} />
                    គ្មាន
                  </label>
                </li>
                <li>២. ការគាំទ្ររួមមាន {toKhmerNum(d.teacherSupportDetails)}</li>
              </ol>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៣.២.៨
            </td>
            <td className="border border-black p-3 font-siemreap">
              ចំនួនភាគរយសិស្សក្រីក្រ សិស្សស្ថិតក្នុងតំបន់ជួបការលំបាក និងសិស្សមានពិការភាពទទួលបានអាហារូបករណ៍
            </td>
            <td className="border border-black pl-5 pr-4 font-siemreap text-justify align-top">
              ចំនួន {toKhmerNum(d.scholarshipPercentage)} %
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center p-3 font-siemreap">
              ៣.៣
            </td>
            <td className="border border-black p-3 font-siemreap" colSpan={2}>
              សេវាសុខាភិបាល
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៣.៣.២
            </td>
            <td className="border border-black p-3 font-siemreap">
              ចំនួនប្រជាពលរដ្ឋទទួលបានសេវាថែទាំសុខភាពបឋមនៅមណ្ឌលសុខភាព (តួលេខនេះត្រូវផ្តល់ដោយមណ្ឌលសុខភាព)
            </td>
            <td className="border border-black pl-5 pr-4 font-siemreap text-justify align-top">
              ចំនួន {toKhmerNum(d.primaryHealthcareRecipients)} នាក់
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៣.៣.៦
            </td>
            <td className="border border-black font-siemreap">
              <ol className="pl-5 space-y-1">
                <li>១. មណ្ឌលសុខភាពនៅឃុំ សង្កាត់</li>
                <li>២. មន្ទីរពេទ្យបង្អែកនៅក្នុងក្រុង ស្រុក ខណ្ឌ</li>
              </ol>
            </td>
            <td className="border border-black font-siemreap pr-4 text-justify align-top">
              <ol className="pl-5 space-y-1">
                <li>១. 
                  <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.hasHealthCenter === "មាន"} />
                    មាន
                  </label>
                  <label className="inline-flex items-center gap-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.hasHealthCenter === "គ្មាន"} />
                    គ្មាន
                  </label>
                </li>
                <li>២. 
                  <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.hasReferralHospital === "មាន"} />
                    មាន
                  </label>
                  <label className="inline-flex items-center gap-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.hasReferralHospital === "គ្មាន"} />
                    គ្មាន
                  </label>
                </li>
              </ol>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៣.៣.៧
            </td>
            <td className="border border-black font-siemreap">
              <ol className="pl-5 space-y-1">
                <li>១. ការលើកទឹកចិត្តដល់គ្រូពេទ្យដែលទៅបំពេញការងារនៅតំបន់ជនបទ តំបន់ដាច់ស្រយាល និងតំបន់ជួបការលំបាក តាមរយៈការផ្តល់ប្រាក់ឧបត្ថម្ភបន្ថែម ឬផ្សេងទៀត</li>
                <li>២. បើមាន សូមរៀបរាប់ការគាំទ្រគ្រូពេទ្យនៅតាមតំបន់ដាច់ស្រយាល និងតំបន់ជួបការលំបាកទាំងនោះ</li>
              </ol>
            </td>
            <td className="border border-black font-siemreap pr-4 text-justify align-top">
              <ol className="pl-5 space-y-1">
                <li>១. 
                  <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.hasDoctorIncentives === "មាន"} />
                    មាន
                  </label>
                  <label className="inline-flex items-center gap-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.hasDoctorIncentives === "គ្មាន"} />
                    គ្មាន
                  </label>
                </li>
                <li>២. ការគាំទ្ររួមមាន {toKhmerNum(d.doctorSupportDetails)}</li>
              </ol>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៣.៣.៩
            </td>
            <td className="border border-black font-siemreap p-3">
              ឃុំ សង្កាត់មានទីកន្លែងហាត់ប្រាណ ឬហាត់កីឡាសាធារណៈ
            </td>
            <td className="border border-black pl-5 pr-4 font-siemreap text-justify align-top">
              <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
                <input type="checkbox" disabled className="accent-blue-600" checked={d.hasPublicExerciseSpace === "មាន"} />
                មាន
              </label>
              <label className="inline-flex items-center gap-4 cursor-not-allowed">
                <input type="checkbox" disabled className="accent-blue-600" checked={d.hasPublicExerciseSpace === "គ្មាន"} />
                គ្មាន
              </label>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៣.៣.១០
            </td>
            <td className="border border-black font-siemreap">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួនកម្មវិធី កិច្ចប្រជុំ ព្រឹត្តិការណ៍ផ្សព្វផ្សាយវិធានសុខាភិបាល ដើម្បីបង្ការ និងទប់ស្កាត់ការឆ្លងរាលដាលជំងឺកូវីដ១៩ និងកាត់បន្ថយការប្រឈមនឹងកត្តាហានិភ័យនៃជំងឺមិនឆ្លងដែលបានរៀបចំ</li>
                <li>២. ចំនួនប្រជាពលរដ្ឋចូលរួមកម្មវិធី កិច្ចប្រជុំ ព្រឹត្តិការណ៍ផ្សព្វផ្សាយការយល់ដឹងរបស់ប្រជាពលរដ្ឋក្នុងការវិធានសុខាភិបាល ដើម្បីបង្ការ និងទប់ស្កាត់ការឆ្លងរាលដាលជំងឺកូវីដ១៩ និងកាត់បន្ថយការប្រឈមនឹងកត្តាហានិភ័យនៃជំងឺមិនឆ្លង</li>
              </ol>
            </td>
            <td className="border border-black font-siemreap pr-4 text-justify align-top">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួន {toKhmerNum(d.healthAwarenessPrograms)} ដង</li>
                <li>២. ចំនួន {toKhmerNum(d.healthAwarenessParticipants)} នាក់</li>
              </ol>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center p-3 font-siemreap">
              ៣.៤
            </td>
            <td className="border border-black p-3 font-siemreap" colSpan={2}>
              ការកសាងហេដ្ឋារចនាសម្ព័ន្ធ កសាងរចនាសម្ព័ន្ធសហគមន៍
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៣.៤.១
            </td>
            <td className="border border-black font-siemreap">
              <ol className="pl-5 space-y-1">
                <li>១. ការកសាងផ្លូវថ្មី (គ្រប់គម្រោងទាំងអស់ដែលបានអភិវឌ្ឍនៅឃុំ សង្កាត់)</li>
                <li>២. ការជួសជុល (គ្រប់គម្រោងទាំងអស់ដែលបានអភិវឌ្ឍនៅឃុំ សង្កាត់)</li>
              </ol>
            </td>
            <td className="border border-black font-siemreap pr-4 text-justify align-top">
              <ol className="pl-5 space-y-1">
                <li>១.១. ការកសាងផ្លូវបេតុងចំនួន {toKhmerNum(d.newConcreteRoads)} ខ្សែ</li>
                <li>១.២. ការកសាងផ្លូវបេតុងស្មើនឹងប្រវែង {toKhmerNum(d.newConcreteRoadKm)} គីឡូម៉ែត្រ</li>
                <li>១.៣. ការកសាងផ្លូវក្រាលកៅស៊ូចំនួន {toKhmerNum(d.newAsphaltRoads)} ខ្សែ</li>
                <li>១.៤. ការកសាងផ្លូវក្រាលកៅស៊ូស្មើនឹងប្រវែង {toKhmerNum(d.newAsphaltRoadKm)} គីឡូម៉ែត្រ</li>
                <li>១.៥. ការជួសជុលផ្លូវដី និងគ្រួសក្រហមចំនួន {toKhmerNum(d.repairedDirtRoads)} ខ្សែ</li>
                <li>១.៦. ការជួសជុលផ្លូវដី និងគ្រួសក្រហមស្មើនឹងប្រវែង {toKhmerNum(d.repairedDirtRoadKm)} គីឡូម៉ែត្រ</li>
                <li>២.១. ការជួសជុលផ្លូវបេតុងចំនួន {toKhmerNum(d.repairConcreteRoads)} ខ្សែ</li>
                <li>២.២. ការជួសជុលផ្លូវបេតុងស្មើនឹងប្រវែង {toKhmerNum(d.repairConcreteRoadKm)} គីឡូម៉ែត្រ</li>
                <li>២.៣. ការជួសជុលផ្លូវក្រាលកៅស៊ូចំនួន {toKhmerNum(d.repairAsphaltRoads)} ខ្សែ</li>
                <li>២.៤. ការជួសជុលផ្លូវក្រាលកៅស៊ូស្មើនឹងប្រវែង {toKhmerNum(d.repairAsphaltRoadKm)} គីឡូម៉ែត្រ</li>
                <li>២.៥. ការកសាងផ្លូវដី និងគ្រួសក្រហមចំនួន {toKhmerNum(d.constructDirtRoads)} ខ្សែ</li>
                <li>២.៦. ការកសាងផ្លូវដី និងគ្រួសក្រហមស្មើនឹងប្រវែង {toKhmerNum(d.constructDirtRoadKm)} គីឡូម៉ែត្រ</li>
              </ol>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៣.៤.២
            </td>
            <td className="border border-black font-siemreap p-3">
              ផ្លូវក្រាលគ្រួសក្រហម ត្រូវបានប្រែក្លាយទៅជាផ្លូវកៅស៊ូ ឬផ្លូវបេតុង
            </td>
            <td className="border border-black font-siemreap pr-4 text-justify align-top">
              <ol className="pl-5 space-y-1">
                <li>១. ផ្លូវក្រាលគ្រួសក្រហម ត្រូវបានប្រែក្លាយទៅជាផ្លូវកៅស៊ូ ឬផ្លូវបេតុងមានចំនួន {toKhmerNum(d.upgradedRoadLines)} ខ្សែ</li>
                <li>២. ផ្លូវក្រាលគ្រួសក្រហម ត្រូវបានប្រែក្លាយទៅជាផ្លូវកៅស៊ូ ឬផ្លូវបេតុងមានចំនួន {toKhmerNum(d.upgradedRoadKm)} គីឡូម៉ែត្រ</li>
              </ol>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៣.៤.៣
            </td>
            <td className="border border-black font-siemreap p-3">
              ការកសាងប្រព័ន្ធប្រឡាយរំដោះទឹក លូបង្អូរទឹក ស្ថានីយបូមទឹក ប្រព័ន្ធចម្រោះទឹកកខ្វក់
            </td>
            <td className="border border-black font-siemreap pr-4 text-justify align-top">
              <ol className="pl-5 space-y-1">
                <li>១. ការកសាងថ្មីប្រព័ន្ធប្រឡាយរំដោះទឹក/លូបង្អូរទឹកចំនួន {toKhmerNum(d.drainageLines)} ខ្សែ</li>
                <li>២. ការកសាងថ្មីប្រព័ន្ធប្រឡាយរំដោះទឹក/លូបង្អូរទឹកចំនួន {toKhmerNum(d.drainageMeters)} ម៉ែត្រ</li>
                <li>៣. ការកសាងថ្មីស្ថានីយបូមទឹក {toKhmerNum(d.pumpingStations)} កន្លែង</li>
                <li>៤. ការកសាងថ្មីប្រព័ន្ធចម្រោះទឹកកខ្វក់ {toKhmerNum(d.waterTreatmentPlants)} កន្លែង</li>
              </ol>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៣.៤.៤
            </td>
            <td className="border border-black font-siemreap">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួនគម្រោងដែលផ្អែកឯកជន សប្បុរសជន និងសហគមន៍មូលដ្ឋាន បានស្តារ ជួសជុល កសាង ថែទាំហេដ្ឋារចនាសម្ព័ន្ធសហគមន៍ក្នុងឃុំ សង្កាត់</li>
                <li>២. ចំនួនគម្រោងដែលផ្អែកឯកជន សប្បុរសជន និងសហគមន៍មូលដ្ឋាន បានស្តារ ជួសជុល កសាង ថែទាំហេដ្ឋារចនាសម្ព័ន្ធសហគមន៍ក្នុងឃុំ សង្កាត់ស្មើនឹងប្រវែង</li>
              </ol>
            </td>
            <td className="border border-black font-siemreap pr-4 text-justify align-top">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួន {toKhmerNum(d.privateCommunityProjects)} គម្រោង</li>
                <li>២. ស្មើនឹង {toKhmerNum(d.privateCommunityProjectsKm)} គីឡូម៉ែត្រ</li>
              </ol>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center p-3 font-siemreap">
              ៣.៥
            </td>
            <td className="border border-black p-3 font-siemreap" colSpan={2}>
              ការផ្គត់ផ្គង់ទឹកស្អាត
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៣.៥.១
            </td>
            <td className="border border-black p-3 font-siemreap">
              ចំនួនភាគរយគ្រួសារក្នុងឃុំ សង្កាត់មានទឹកស្អាតសម្រាប់ផឹក និងប្រើប្រាស់ក្នុងជីវភាពប្រចាំថ្ងៃតាមរយៈទឹកបំពង់ ការស្តារ ដឹកស្រះ អណ្ដូងទឹក
            </td>
            <td className="border border-black pl-5 pr-4 font-siemreap text-justify align-top">
              ចំនួន {toKhmerNum(d.cleanWaterPct)} %
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៣.៥.២
            </td>
            <td className="border border-black p-3 font-siemreap">
              ចំនួនភាគរយគ្រួសារក្នុងឃុំ សង្កាត់ ដែលមានទឹកស្អាតប្រើប្រាស់តាមរយៈទឹកបំពង់
            </td>
            <td className="border border-black pl-5 pr-4 font-siemreap text-justify align-top">
              ចំនួន {toKhmerNum(d.pipedWaterPct)} %
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center p-3 font-siemreap">
              ៣.៦
            </td>
            <td className="border border-black p-3 font-siemreap" colSpan={2}>
              ការរក្សាប្រភពទឹក និងការពង្រីកប្រព័ន្ធស្រោចស្រព
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៣.៦.១
            </td>
            <td className="border border-black p-3 font-siemreap">
              ចំនួនអាងស្តុកទឹកខ្នាតតូចនៅតាមឃុំ សង្កាត់
            </td>
            <td className="border border-black pl-5 pr-4 font-siemreap text-justify align-top">
              ចំនួន {toKhmerNum(d.smallReservoirs)} កន្លែង
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៣.៦.២
            </td>
            <td className="border border-black font-siemreap">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួនព្រែក បឹងបួរ អូរធម្មជាតិ និងជីកស្រះ ដែលត្រូវដកស្តារ និងជីកថ្មី</li>
                <li>២. ចំនួនព្រែក បឹងបួរ អូរធម្មជាតិ និងជីកស្រះ ដែលត្រូវដកស្តារ និងជីកថ្មី ស្មើនឹងប្រវែង</li>
              </ol>
            </td>
            <td className="border border-black font-siemreap pr-4 text-justify align-top">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួន {toKhmerNum(d.restoredWaterBodies)} កន្លែង</li>
                <li>២. ស្មើនឹងប្រវែង {toKhmerNum(d.restoredWaterBodiesM)} ម៉ែត្រ</li>
              </ol>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៣.៦.៤
            </td>
            <td className="border border-black font-siemreap">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួនប្រឡាយស្រោចស្រពនៅតាមឃុំ សង្កាត់ដែលបានកសាង</li>
                <li>២. ចំនួនប្រឡាយស្រោចស្រពនៅតាមឃុំ សង្កាត់ដែលបានពង្រីកថ្មី</li>
              </ol>
            </td>
            <td className="border border-black font-siemreap pr-4 text-justify align-top">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួន {toKhmerNum(d.irrigationCanals)} ខ្សែ</li>
                <li>២. ស្មើនឹង {toKhmerNum(d.irrigationCanalsMeters)} ម៉ែត្រ</li>
              </ol>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៣.៦.៥
            </td>
            <td className="border border-black p-3 font-siemreap">
              ចំនួនប្រព័ន្ធបញ្ចូលទឹក
            </td>
            <td className="border border-black pl-5 pr-4 font-siemreap text-justify align-top">
              ចំនួន {toKhmerNum(d.waterInletSystems)}
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៣.៦.៦
            </td>
            <td className="border border-black p-3 font-siemreap">
              ចំនួនវគ្គបណ្តុះបណ្តាលដែលក្រុមប្រឹក្សាឃុំ សង្កាត់ទទួលបានពាក់ព័ន្ធលើការគ្រប់គ្រង ការអភិវឌ្ឍ និងការអភិរក្សព្រែក អូរ និងបឹងបួរធម្មជាតិ
            </td>
            <td className="border border-black pl-5 pr-4 font-siemreap text-justify align-top">
              ចំនួន {toKhmerNum(d.waterManagementTraining)} វគ្គ
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៣.៦.៧
            </td>
            <td className="border border-black font-siemreap">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួនសហគមន៍កសិករប្រើប្រាស់ទឹកដែលបានបង្កើតនៅតាមឃុំ សង្កាត់</li>
                <li>២. ចំនួនវគ្គបណ្តុះបណ្តាលដល់សហគមន៍កសិករប្រើប្រាស់ទឹក</li>
              </ol>
            </td>
            <td className="border border-black font-siemreap pr-4 text-justify align-top">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួន {toKhmerNum(d.farmingCommunities)} សហគមន៍</li>
                <li>២. ចំនួន {toKhmerNum(d.farmingCommunityTraining)} វគ្គ</li>
              </ol>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៣.៦.៨
            </td>
            <td className="border border-black p-3 font-siemreap">
              ការធ្វើអន្តរាគមន៍បូមទឹកសង្គ្រោះនៅពេលជួបគ្រោះរាំងស្ងួត
            </td>
            <td className="border border-black pl-5 pr-4 font-siemreap text-justify align-top">
              <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
                <input type="checkbox" disabled className="accent-blue-600" checked={d.hasDroughtPumping === "មាន"} />
                មាន
              </label>
              <label className="inline-flex items-center gap-4 cursor-not-allowed">
                <input type="checkbox" disabled className="accent-blue-600" checked={d.hasDroughtPumping === "គ្មាន"} />
                គ្មាន
              </label>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center p-3 font-siemreap">
              ៣.៧
            </td>
            <td className="border border-black p-3 font-siemreap" colSpan={2}>
              ការផ្គត់ផ្គង់ថាមពលអគ្គិសនី
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៣.៧.១
            </td>
            <td className="border border-black p-3 font-siemreap">
              ភាគរយនៃភូមិក្នុងឃុំ សង្កាត់នីមួយៗ មានអគ្គិសនីប្រើប្រាស់ពេញលេញ
            </td>
            <td className="border border-black pl-5 pr-4 font-siemreap text-justify align-top">
              ចំនួន {toKhmerNum(d.electricityCoveragePct)} %
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center p-3 font-siemreap">
              ៣.៨
            </td>
            <td className="border border-black p-3 font-siemreap" colSpan={2}>
              បច្ចេកវិទ្យា គមនាគមន៍ និងព័ត៌មាន
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៣.៨.៣
            </td>
            <td className="border border-black font-siemreap">
              <ol className="pl-5 space-y-1">
                <li>១. ឃុំ សង្កាត់មានគេហទំព័រ (Website) និងកម្មវិធីទូរស័ព្ទដៃ (Apps) សម្រាប់ផ្តល់ព័ត៌មាន និងចែករំលែកឯកសារនានា</li>
                <li>២. មន្ទីរពេទ្យបង្អែក មណ្ឌលសុខភាពមានគេហទំព័រ (Website) និងកម្មវិធីទូរស័ព្ទដៃ (Apps) សម្រាប់ផ្តល់ព័ត៌មាន និងចែករំលែកឯកសារនានា</li>
                <li>៣. សាលារៀនមានគេហទំព័រ (Website) និងកម្មវិធីទូរស័ព្ទដៃ (Apps) សម្រាប់ផ្តល់ព័ត៌មាន និងចែករំលែកឯកសារនានា</li>
                <li>៤. ប៉ុស្តិ៍នគរបាល មានគេហទំព័រ (Website) និងកម្មវិធីទូរស័ព្ទដៃ (Apps) សម្រាប់ផ្តល់ព័ត៌មាន និងចែករំលែកឯកសារនានា</li>
              </ol>
            </td>
            <td className="border border-black font-siemreap pr-4 text-justify align-top">
              <ol className="pl-5 space-y-1">
                <li>១. 
                  <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.hasCommuneWebsite === "មាន"} />
                    មាន
                  </label>
                  <label className="inline-flex items-center gap-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.hasCommuneWebsite === "គ្មាន"} />
                    គ្មាន
                  </label>
                </li>
                <li>២. 
                  <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.hasHealthCenterWebsite === "មាន"} />
                    មាន
                  </label>
                  <label className="inline-flex items-center gap-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.hasHealthCenterWebsite === "គ្មាន"} />
                    គ្មាន
                  </label>
                </li>
                <li>៣. 
                  <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.hasSchoolWebsite === "មាន"} />
                    មាន
                  </label>
                  <label className="inline-flex items-center gap-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.hasSchoolWebsite === "គ្មាន"} />
                    គ្មាន
                  </label>
                </li>
                <li>៤. 
                  <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.hasPoliceWebsite === "មាន"} />
                    មាន
                  </label>
                  <label className="inline-flex items-center gap-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.hasPoliceWebsite === "គ្មាន"} />
                    គ្មាន
                  </label>
                </li>
              </ol>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center p-3 font-siemreap">
              ៣.៩
            </td>
            <td className="border border-black p-3 font-siemreap" colSpan={2}>
              ការគ្រប់គ្រងដីធ្លី សំណង់ ការរៀបចំដែនដី និងនគរូបនីយកម្ម
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៣.៩.៤
            </td>
            <td className="border border-black p-3 font-siemreap">
              ចំនួនករណីសម្របសម្រួលដោះស្រាយវិវាទដីធ្លីនៅឃុំ សង្កាត់
            </td>
            <td className="border border-black pl-5 pr-4 font-siemreap text-justify align-top">
              ចំនួន {toKhmerNum(d.landDisputeCases)} ករណី
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៣.៩.៥
            </td>
            <td className="border border-black p-3 font-siemreap">
              ឃុំ សង្កាត់បានរៀបចំផែនការប្រើប្រាស់ដី និងប្លង់គោលប្រើប្រាស់ដីទីប្រជុំជន
            </td>
            <td className="border border-black pl-5 pr-4 font-siemreap text-justify align-top">
              <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
                <input type="checkbox" disabled className="accent-blue-600" checked={d.hasLandUsePlan === "មាន"} />
                មាន
              </label>
              <label className="inline-flex items-center gap-4 cursor-not-allowed">
                <input type="checkbox" disabled className="accent-blue-600" checked={d.hasLandUsePlan === "គ្មាន"} />
                គ្មាន
              </label>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៣.៩.៧
            </td>
            <td className="border border-black p-3 font-siemreap">
              ចំនួនសហគមន៍ក្នុងគោលដៅសន្សំប្រាក់ ប្រាស់កម្លាំងពលកម្ម ជំនាញសាងសង់ផ្ទះធនធាន ហិរញ្ញវត្ថុ
            </td>
            <td className="border border-black pl-5 pr-4 font-siemreap text-justify align-top">
              ចំនួន {toKhmerNum(d.targetCommunities)} សហគមន៍
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center p-3 font-siemreap">
              ៣.១០
            </td>
            <td className="border border-black p-3 font-siemreap" colSpan={2}>
              ការងារអនាម័យ និងបរិស្ថាន
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៣.១០.១
            </td>
            <td className="border border-black p-3 font-siemreap">
              ឃុំ សង្កាត់មានយន្តការប្រមូលសំរាម សំណល់រឹង សំណល់រាវ និងការបំពុលបរិស្ថាន ផ្សេងទៀត
            </td>
            <td className="border border-black pl-5 pr-4 font-siemreap text-justify align-top">
              <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
                <input type="checkbox" disabled className="accent-blue-600" checked={d.hasWasteCollection === "មាន"} />
                មាន
              </label>
              <label className="inline-flex items-center gap-4 cursor-not-allowed">
                <input type="checkbox" disabled className="accent-blue-600" checked={d.hasWasteCollection === "គ្មាន"} />
                គ្មាន
              </label>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៣.១០.២
            </td>
            <td className="border border-black font-siemreap">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួនកម្មវិធីផ្សព្វផ្សាយអំពីច្បាប់ គោលការណ៍ និងវិធានការនានាស្តីពីកិច្ចការពារថែរក្សា បរិស្ថាន រួមទាំងវិធីសាស្ត្រនៃការថែរក្សាសុខភាព សុវត្ថិភាពចំណីអាហារ ផលប៉ះពាល់ពីការប្រើប្រាស់សារធាតុគីមី ការប្រើគ្រឿងស្រវឹង និងថ្នាំជក់</li>
                <li>២. ចំនួនប្រជាពលរដ្ឋចូលរួមកម្មវិធីផ្សព្វផ្សាយច្បាប់ គោលការណ៍ និងវិធានការនានា ស្តីពីកិច្ចការពារថែរក្សាបរិស្ថាន រួមទាំងវិធីសាស្ត្រនៃការថែរក្សាសុខភាព សុវត្ថិភាពចំណីអាហារ ផលប៉ះពាល់ពីការប្រើប្រាស់សារធាតុគីមី ការប្រើគ្រឿងស្រវឹង និងថ្នាំជក់</li>
              </ol>
            </td>
            <td className="border border-black font-siemreap pr-4 text-justify align-top">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួន {toKhmerNum(d.environmentalLawPrograms)} ដង</li>
                <li>២. ចំនួន {toKhmerNum(d.environmentalLawParticipants)} នាក់</li>
              </ol>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៣.១០.៣
            </td>
            <td className="border border-black font-siemreap">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួនកម្មវិធីផ្សព្វផ្សាយការរស់នៅស្អាតប្រកបដោយចីរភាព ការអប់រំ ផ្សព្វផ្សាយ ស្អាត ភូមិ ឃុំ សង្កាត់ និងជួយលើកទឹកចិត្តឱ្យប្រជាពលរដ្ឋចូលរួមក្នុងចលនាប្រឡងប្រណាំង មេត្រីភាពបរិស្ថានភូមិ ឃុំ សង្កាត់</li>
                <li>២. ឃុំ សង្កាត់ដែលបានបញ្ចូលគោលការណ៍អភិវឌ្ឍន៍ដោយចីរភាពទៅក្នុងផែនការ អភិវឌ្ឍន៍ឃុំ សង្កាត់</li>
              </ol>
            </td>
            <td className="border border-black font-siemreap pr-4 text-justify align-top">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួន {toKhmerNum(d.greenVillagePrograms)} ដង</li>
                <li>២. 
                  <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.hasGreenVillageProgram === "មាន"} />
                    មាន
                  </label>
                  <label className="inline-flex items-center gap-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.hasGreenVillageProgram === "គ្មាន"} />
                    គ្មាន
                  </label>
                </li>
              </ol>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៣.១០.៤
            </td>
            <td className="border border-black font-siemreap">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួនកម្មវិធីអប់រំផ្សព្វផ្សាយគ្រោះថ្នាក់ដែលបណ្តាលមកពីការពុលចំណីអាហារ ភេសជ្ជៈ នានា</li>
              </ol>
            </td>
            <td className="border border-black font-siemreap pr-4 text-justify align-top">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួន {toKhmerNum(d.foodSafetyPrograms)} ដង</li>
                <li>២. ចំនួន {toKhmerNum(d.foodPoisoningCases)} ករណី</li>
              </ol>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center p-3 font-siemreap">
              ៣.១១
            </td>
            <td className="border border-black p-3 font-siemreap" colSpan={2}>
              ការបង្ការ និងការទប់ស្កាត់ការប្រើប្រាស់សារធាតុ គ្រឿងញៀន និងការឆ្លងជំងឺមហារីក
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៣.១១.១
            </td>
            <td className="border border-black p-3 font-siemreap">
              ចំនួនគ្រួសារដែលទទួលបានការឧបត្ថម្ភគាំទ្រចំណីអាហារ និងសម្លៀកបំពាក់ ដែលជួបការលំបាក និងខ្វះខាតដោយសារផលប៉ះពាល់នៃជំងឺឆ្លង និងជំងឺរាតត្បាតកាចសាហាវ នានា
            </td>
            <td className="border border-black pl-5 pr-4 font-siemreap text-justify align-top">
              ចំនួន {toKhmerNum(d.smallBusinessesCount)} គ្រួសារ
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៣.១១.២
            </td>
            <td className="border border-black p-3 font-siemreap">
              ឃុំ សង្កាត់មានយន្តការសង្គ្រោះបឋម និងផ្តល់យោបល់ការថែទាំសុខភាពដល់ប្រជាពលរដ្ឋដែលទទួលរងគ្រោះថ្នាក់ដោយសារទឹកជំនន់
            </td>
            <td className="border border-black pl-5 pr-4 font-siemreap text-justify align-top">
              <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
                <input type="checkbox" disabled className="accent-blue-600" checked={d.hasEmergencyResponse === "មាន"} />
                មាន
              </label>
              <label className="inline-flex items-center gap-4 cursor-not-allowed">
                <input type="checkbox" disabled className="accent-blue-600" checked={d.hasEmergencyResponse === "គ្មាន"} />
                គ្មាន
              </label>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៣.១១.៣
            </td>
            <td className="border border-black p-3 font-siemreap">
              ឃុំ សង្កាត់មានរៀបចំប្រព័ន្ធការពារ និងផ្តល់សេវាសង្គ្រោះបន្ទាន់ដល់ជនរងគ្រោះ តាមរយៈអន្តរាគមន៍ជួយសង្គ្រោះពីគ្រោះធម្មជាតិ គ្រោះថ្នាក់ការងារ និងការស្វែងរកទិន្នន័យគ្រោះថ្នាក់ ប្រើប្រាស់ប្រចាំថ្ងៃ
            </td>
            <td className="border border-black pl-5 pr-4 font-siemreap text-justify align-top">
              <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
                <input type="checkbox" disabled className="accent-blue-600" checked={d.hasDisasterPreparedness === "មាន"} />
                មាន
              </label>
              <label className="inline-flex items-center gap-4 cursor-not-allowed">
                <input type="checkbox" disabled className="accent-blue-600" checked={d.hasDisasterPreparedness === "គ្មាន"} />
                គ្មាន
              </label>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៣.១១.៤
            </td>
            <td className="border border-black p-3 font-siemreap">
              ឃុំ សង្កាត់មានយន្តការតាមដាន ត្រួតពិនិត្យផលប៉ះពាល់សង្គមក្នុងមូលដ្ឋាន នៅក្នុងការកសាងប្រព័ន្ធការពារសិទ្ធិមនុស្សដល់ប្រជាជនជាសហគមន៍ដែលរងគ្រោះដោយគ្រោះថ្នាក់ការងារ សម្របសម្រួល ដោយអាជ្ញាធរមិនមានការរើសអើង និងមិនមានជម្លោះដីធ្លីក្នុងរយៈពេលវែងឡើយ
            </td>
            <td className="border border-black pl-5 pr-4 font-siemreap text-justify align-top">
              <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
                <input type="checkbox" disabled className="accent-blue-600" checked={d.hasHumanRightsProtection === "មាន"} />
                មាន
              </label>
              <label className="inline-flex items-center gap-4 cursor-not-allowed">
                <input type="checkbox" disabled className="accent-blue-600" checked={d.hasHumanRightsProtection === "គ្មាន"} />
                គ្មាន
              </label>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center p-3 font-siemreap">
              ៤
            </td>
            <td className="border border-black p-3 font-siemreap" colSpan={2}>
              ជាឃុំ សង្កាត់ដែលមានការអភិវឌ្ឍសេដ្ឋកិច្ចមូលដ្ឋាន ដើម្បីលើកកម្ពស់ជីវភាពរស់នៅរបស់ប្រជាពលរដ្ឋ
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center p-3 font-siemreap">
              ៤.១
            </td>
            <td className="border border-black p-3 font-siemreap" colSpan={2}>
              ការលើកកម្ពស់របរ មុខរបរ និងវគ្គបណ្តុះបណ្តាលវិជ្ជាជីវៈដល់ប្រជាពលរដ្ឋ
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៤.១.១
            </td>
            <td className="border border-black font-siemreap">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួនសហគ្រាសខ្នាតតូចដើម្បីជីវភាព និងកែច្នៃផលិតផលក្នុងឃុំ សង្កាត់ជាផ្លូវការ លក្ខណៈ គ្រួសារ ឬសហគមន៍ដែលបានបង្កើត</li>
                <li>២. ចំនួនសហគ្រាសខ្នាតតូចដើម្បីជីវភាព និងកែច្នៃផលិតផលក្នុងឃុំ សង្កាត់ជាផ្លូវការ លក្ខណៈ គ្រួសារ ឬសហគមន៍ដែលទទួលបានចុះបញ្ជីដោយឃុំ សង្កាត់</li>
              </ol>
            </td>
            <td className="border border-black font-siemreap pr-4 text-justify align-top">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួន {toKhmerNum(d.smallBusinessesCount)} សហគ្រាស</li>
                <li>២. ចំនួន {toKhmerNum(d.registeredSmallBusinesses)} សហគ្រាស</li>
              </ol>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៤.១.២
            </td>
            <td className="border border-black p-3 font-siemreap">
              ការផ្សព្វផ្សាយព័ត៌មានគ្រប់គ្រងហិរញ្ញវត្ថុដល់ប្រជាពលរដ្ឋនៅក្នុងឃុំ សង្កាត់
            </td>
            <td className="border border-black pl-5 pr-4 font-siemreap text-justify align-top">
              <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
                <input type="checkbox" disabled className="accent-blue-600" checked={d.hasFinancialLiteracy === "បាន"} />
                បាន
              </label>
              <label className="inline-flex items-center gap-4 cursor-not-allowed">
                <input type="checkbox" disabled className="accent-blue-600" checked={d.hasFinancialLiteracy === "មិនបាន"} />
                មិនបាន
              </label>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៤.១.៣
            </td>
            <td className="border border-black p-3 font-siemreap">
              ការបង្កើតយន្តការបណ្តុះបណ្តាលជំនាញដល់យុវជនក្នុងឃុំ សង្កាត់
            </td>
            <td className="border border-black pl-5 pr-4 font-siemreap text-justify align-top">
              <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
                <input type="checkbox" disabled className="accent-blue-600" checked={d.hasYouthSkillsTraining === "មាន"} />
                មាន
              </label>
              <label className="inline-flex items-center gap-4 cursor-not-allowed">
                <input type="checkbox" disabled className="accent-blue-600" checked={d.hasYouthSkillsTraining === "គ្មាន"} />
                គ្មាន
              </label>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៤.១.៤
            </td>
            <td className="border border-black p-3 font-siemreap">
              ការបង្កើតផ្សារសហគមន៍ក្នុងឃុំ សង្កាត់
            </td>
            <td className="border border-black pl-5 pr-4 font-siemreap text-justify align-top">
              រួមមាន {toKhmerNum(d.hasCommunityMarket)}
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៤.៣.១
            </td>
            <td className="border border-black font-siemreap">
              <ol className="pl-5 space-y-1">
                <li>១. ការផ្សព្វផ្សាយអំពីសារៈសំខាន់ និងការចូលរួមរបស់ប្រជាពលរដ្ឋក្នុងការថែរក្សា ការពារ សម្បត្តិវប្បធម៌ បេតិកភណ្ឌជាតិ អត្តសញ្ញាណ និងប្រពៃណី ទំនៀមទម្លាប់ដ៏ថ្លៃថ្លារបស់ជាតិនៅក្នុងឃុំ សង្កាត់</li>
                <li>២. ការបណ្តុះបណ្តាលអំពីជំនាញសិល្បៈ សិល្បៈស្មូន និងសិល្បៈកម្រដទៃទៀតរបស់ប្រជាជន នៅតាមមូលដ្ឋាន និងសហគមន៍ជនជាតិដើមភាគតិច</li>
              </ol>
            </td>
            <td className="border border-black font-siemreap pr-4 text-justify align-top">
              <ol className="pl-5 space-y-1">
                <li>១. 
                  <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.hasCulturalPromotion === "មាន"} />
                    មាន
                  </label>
                  <label className="inline-flex items-center gap-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.hasCulturalPromotion === "មិនមាន"} />
                    មិនមាន
                  </label>
                </li>
                <li>២. 
                  <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.hasArtsTraining === "បាន"} />
                    បាន
                  </label>
                  <label className="inline-flex items-center gap-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.hasArtsTraining === "មិនបាន"} />
                    មិនបាន
                  </label>
                </li>
              </ol>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៤.៣.២
            </td>
            <td className="border border-black p-3 font-siemreap">
              ចំនួនករណីបទល្មើសធនធានធម្មជាតិដែលត្រូវបានទប់ស្កាត់ ឬបង្ក្រាប
            </td>
            <td className="border border-black pl-5 pr-4 font-siemreap text-justify align-top">
              ចំនួន {toKhmerNum(d.naturalResourceCrimeCases)} ករណី
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៤.៣.៤
            </td>
            <td className="border border-black p-3 font-siemreap">
              ឃុំ សង្កាត់បានបញ្ចូលគម្រោងការបង្កើតមុខរបរថ្មីៗសម្រាប់សហគមន៍តំបន់ការពារធម្មជាតិទៅក្នុងផែនការអភិវឌ្ឍន៍ និងកម្មវិធីវិនិយោគបីឆ្នាំរំកិលឃុំ សង្កាត់
            </td>
            <td className="border border-black font-siemreap pr-4 text-justify align-top">
              <ol className="pl-5 space-y-1">
                <li>១. 
                  <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.hasNewMarketProjects === "មាន"} />
                    មាន
                  </label>
                  <label className="inline-flex items-center gap-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.hasNewMarketProjects === "មិនមាន"} />
                    មិនមាន
                  </label>
                </li>
                <li>២. ប្រសិនបើមាន មានមុខរបរអ្វីខ្លះ៖ {toKhmerNum(d.newMarketDetails)}</li>
              </ol>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៤.៣.៦
            </td>
            <td className="border border-black p-3 font-siemreap">
              ចំនួនសហគមន៍ទេសចរណ៍ មូលដ្ឋានដែលបានបង្កើតក្នុងឃុំ សង្កាត់ដែលមានតំបន់ទេសចរណ៍
            </td>
            <td className="border border-black pl-5 pr-4 font-siemreap text-justify align-top">
              ចំនួន {toKhmerNum(d.tourismCommunities)} សហគមន៍
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center p-3 font-siemreap">
              ៤.៤
            </td>
            <td className="border border-black p-3 font-siemreap" colSpan={2}>
              ការអភិវឌ្ឍ និងគ្រប់គ្រងផ្សារ
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៤.៤.២
            </td>
            <td className="border border-black p-3 font-siemreap">
              ចំនួនផ្សារដែលបានសាងសង់ កែលម្អ ឬរៀបចំឡើងវិញដែលបានដំណើរការ និងមានលក្ខណៈសមស្របនៅក្នុងឃុំ សង្កាត់
            </td>
            <td className="border border-black pl-5 pr-4 font-siemreap text-justify align-top">
              ចំនួន {toKhmerNum(d.marketCount)} ផ្សារ
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center align-top p-3 font-siemreap">
              ៤.៤.៣
            </td>
            <td className="border border-black font-siemreap">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួនផ្សារដែលមានគណៈកម្មការគ្រប់គ្រង</li>
                <li>២. ការគ្រប់គ្រងផ្សារនៅតាមមូលដ្ឋានឃុំ សង្កាត់ឱ្យមានសុវត្ថិភាព សណ្តាប់ធ្នាប់ អនាម័យ និងបរិស្ថានល្អ</li>
              </ol>
            </td>
            <td className="border border-black font-siemreap pr-4 text-justify align-top">
              <ol className="pl-5 space-y-1">
                <li>១. ចំនួន {toKhmerNum(d.hasMarketManagement)} ផ្សារ</li>
                <li>២. 
                  <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.marketManagementQuality === "ល្អ"} />
                    ល្អ
                  </label>
                  <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.marketManagementQuality === "មធ្យម"} />
                    មធ្យម
                  </label>
                  <label className="inline-flex items-center gap-4 cursor-not-allowed">
                    <input type="checkbox" disabled className="accent-blue-600" checked={d.marketManagementQuality === "មិនទាន់បានល្អ"} />
                    មិនទាន់បានល្អ
                  </label>
                </li>
              </ol>
            </td>
          </tr>
          <tr>
            <td className="border border-black text-center p-3 font-siemreap">
              ៤.៥
            </td>
            <td className="border border-black p-3 font-siemreap" colSpan={2}>
              ការអភិវឌ្ឍសេដ្ឋកិច្ចមូលដ្ឋាននៅតាមតំបន់ព្រំដែន
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}
