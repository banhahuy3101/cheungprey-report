import type { EvaluationData } from "@/lib/evaluation-schema";

const khmerDigits: Record<string, string> = {
  "0": "០", "1": "១", "2": "២", "3": "៣", "4": "៤",
  "5": "៥", "6": "៦", "7": "៧", "8": "៨", "9": "៩",
};

function toKhmerNum(value: string | undefined): string {
  return (value || ".........").replace(/\d/g, (d) => khmerDigits[d]);
}

interface Section1Props {
  data: Partial<EvaluationData>;
}

export default function Section1Democracy({ data: d }: Section1Props) {
  return (
    <table className="w-full border-collapse border border-black">
      <thead>
        <tr>
          <th className="border border-black w-20 p-1 text-center font-moul">ល.រ</th>
          <th className="border border-black p-1 font-moul">សូចនាករ</th>
          <th className="border border-black w-[40%] p-1 font-moul">
            <div className="text-wrap font-moul text-xs">
              ទិន្នន័យ ឬព័ត៌មាន លទ្ធផលនៃការអនុវត្ត
            </div>
          </th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td className="border border-black text-center p-3 font-siemreap">១</td>
          <td className="border border-black p-3 font-siemreap" colSpan={2}>
            ជាឃុំ សង្កាត់ដែលលើកកម្ពស់លទ្ធិប្រជាធិបតេយ្យនៅមូលដ្ឋាន និងសិទ្ធិសេរីភាពរបស់ប្រជាជនគ្រប់រូប ប្រជាជនរស់នៅដោយសុខដុមរមនា
          </td>
        </tr>
        <tr>
          <td className="border border-black text-center p-3 font-siemreap">១.១</td>
          <td className="border border-black p-3 font-siemreap" colSpan={2}>
            ការលើកកម្ពស់លទ្ធិប្រជាធិបតេយ្យនៅមូលដ្ឋាន
          </td>
        </tr>
        <tr>
          <td className="border border-black text-center align-top p-3 font-siemreap">១.១.២</td>
          <td className="border border-black font-siemreap">
            <ol className="pl-5 space-y-1">
              <li>១. ភាគរយចំនួនប្រជាពលរដ្ឋគ្រប់អាយុ១៨ឆ្នាំ ទៅចុះឈ្មោះបោះឆ្នោតតំណាងរាស្ត្រ</li>
              <li>២. ភាគរយចំនួនប្រជាពលរដ្ឋគ្រប់អាយុ១៨ឆ្នាំ ទៅចុះឈ្មោះបោះឆ្នោតឃុំ សង្កាត់</li>
              <li>៣. ភាគរយនៃចំនួនប្រជាពលរដ្ឋមានឈ្មោះបោះឆ្នោតបានទៅបោះឆ្នោតតំណាងរាស្ត្រ</li>
              <li>៤. ភាគរយនៃចំនួនប្រជាពលរដ្ឋមានឈ្មោះបោះឆ្នោតបានទៅបោះឆ្នោតឃុំ សង្កាត់</li>
              <li>៥. ករណីអំពើហិង្សាពាក់ព័ន្ធនឹងការបោះឆ្នោតតំណាងរាស្ត្រឆ្នាំ២០២៣</li>
              <li>៦. ករណីអំពើហិង្សាពាក់ព័ន្ធនឹងការបោះឆ្នោតឃុំ សង្កាត់២០២២</li>
            </ol>
          </td>
          <td className="border border-black font-siemreap pr-4 text-justify align-top">
            <ol className="pl-5 space-y-1 text-wrap">
              <li>១. ចំនួន {toKhmerNum(d.registeredVotersNational2023)}% ប្រជាពលរដ្ឋគ្រប់អាយុ១៨ឆ្នាំ ទៅចុះឈ្មោះបោះឆ្នោតតំណាងរាស្ត្រ២០២៣</li>
              <li>២. ចំនួន {toKhmerNum(d.registeredVotersCommune2022)}% ប្រជាពលរដ្ឋគ្រប់អាយុ១៨ឆ្នាំ ទៅចុះឈ្មោះបោះឆ្នោតឃុំ សង្កាត់២០២២</li>
              <li>៣. ចំនួន {toKhmerNum(d.voterTurnoutNational2023)}% ប្រជាពលរដ្ឋមានឈ្មោះបោះឆ្នោតបានទៅបោះឆ្នោតតំណាងរាស្ត្រ២០២៣</li>
              <li>៤. ចំនួន {toKhmerNum(d.voterTurnoutCommune2022)} ប្រជាពលរដ្ឋមានឈ្មោះបោះឆ្នោតបានទៅបោះឆ្នោតឃុំ សង្កាត់២០២២</li>
              <li>៥. ចំនួន {toKhmerNum(d.violenceCasesNational2023)} ករណីពាក់ព័ន្ធនឹងការបោះឆ្នោតតំណាងរាស្ត្រ២០២៣</li>
              <li>៦. ចំនួន {toKhmerNum(d.violenceCasesCommune2022)} ករណីពាក់ព័ន្ធនឹងការបោះឆ្នោតបោះឆ្នោតឃុំ សង្កាត់២០២២</li>
            </ol>
          </td>
        </tr>
        <tr>
          <td className="border border-black text-center align-top p-3 font-siemreap">១.១.៣</td>
          <td className="border border-black font-siemreap">
            <ol className="pl-5 space-y-1">
              <li>១. ចំនួនសមាជិកក្រុមប្រឹក្សាឃុំ សង្កាត់មានសញ្ញាបត្រមធ្យមសិក្សាទុតិយភូមិ បរិញ្ញាបត្ររង បរិញ្ញាបត្រ បរិញ្ញាបត្រជាន់ខ្ពស់</li>
              <li>២. ចំនួនសមាជិកក្រុមប្រឹក្សាឃុំ សង្កាត់ដែលត្រូវដកចេញពីមុខតំណែងដោយសារ ឬ ទទួលទណ្ឌកម្មវិន័យពាក់ព័ន្ធអាប្បកិរិយា មិនស្អាតស្អំ ការមិនគោរពច្បាប់ ការរើសអើង</li>
            </ol>
          </td>
          <td className="border border-black font-siemreap pr-4 text-justify align-top">
            <ol className="pl-5 space-y-1">
              <li>១.១. ចំនួនសមាជិកក្រុមប្រឹក្សាឃុំ សង្កាត់មានសញ្ញាបត្រមធ្យមសិក្សាទុតិយភូមិ {toKhmerNum(d.highSchoolDiploma)} នាក់</li>
              <li>១.២. ចំនួនសមាជិកក្រុមប្រឹក្សាឃុំ សង្កាត់មានបរិញ្ញាបត្ររង {toKhmerNum(d.associateDegree)} នាក់</li>
              <li>១.៣. ចំនួនសមាជិកក្រុមប្រឹក្សាឃុំ សង្កាត់មានបរិញ្ញាបត្រ {toKhmerNum(d.bachelorDegree)} នាក់</li>
              <li>១.៤. ចំនួនសមាជិកក្រុមប្រឹក្សាឃុំ សង្កាត់មានបរិញ្ញាបត្រជាន់ខ្ពស់ឡើង {toKhmerNum(d.masterDegree)} នាក់</li>
              <li>២. ចំនួនសមាជិកក្រុមប្រឹក្សាឃុំ សង្កាត់ដែលត្រូវដកចេញពីមុខតំណែងដោយសារ ឬ ទទួលទណ្ឌកម្មវិន័យពាក់ព័ន្ធអាប្បកិរិយា មិនស្អាតស្អំ ការមិនគោរពច្បាប់ ការរើសអើង {toKhmerNum(d.removedCouncilMembers)} នាក់</li>
            </ol>
          </td>
        </tr>
        <tr>
          <td className="border border-black text-center align-top p-3 font-siemreap">១.១.៤</td>
          <td className="border border-black font-siemreap">
            <ol className="pl-5 space-y-1">
              <li>១. ចំនួនសមាជិកក្រុមប្រឹក្សាឃុំ សង្កាត់មានសញ្ញាបត្រមធ្យមសិក្សាទុតិយភូមិ បរិញ្ញាបត្ររង បរិញ្ញាបត្រ បរិញ្ញាបត្រជាន់ខ្ពស់</li>
            </ol>
          </td>
          <td className="border border-black font-siemreap pr-4 text-justify align-top">
            <ol className="pl-5 space-y-1">
              <li>១.១. ចំនួនសរុបនៃសមាជិកក្រុមប្រឹក្សាឃុំ សង្កាត់ {toKhmerNum(d.totalCouncilMembers)}</li>
              <li>១.២. ចំនួនសមាជិកក្រុមប្រឹក្សាឃុំ សង្កាត់ជាស្រ្តី {toKhmerNum(d.femaleCouncilMembers)}</li>
              <li>១.៣. ចំនួនសមាជិកក្រុមប្រឹក្សាឃុំ សង្កាត់ជាយុវជន (ក្រោម៣៥ឆ្នាំ) {toKhmerNum(d.youthCouncilMembers)}</li>
              <li>១.៤. ចំនួនសរុបស្មៀនឃុំ សង្កាត់ {toKhmerNum(d.totalClerks)} នាក់</li>
              <li>១.៥. ចំនួនសរុបស្មៀនឃុំ សង្កាត់ជាស្រ្តី {toKhmerNum(d.femaleClerks)} នាក់</li>
              <li>១.៦. ចំនួនសរុបស្មៀនឃុំ សង្កាត់ជាយុវជន (ក្រោម៣៥ឆ្នាំ) {toKhmerNum(d.youthClerks)} នាក់</li>
              <li>១.៧. ចំនួនសរុបថ្នាក់ដឹកនាំភូមិ {toKhmerNum(d.totalVillageLeaders)} នាក់</li>
              <li>១.៨. ចំនួនថ្នាក់ដឹកនាំភូមិជាស្រ្តី {toKhmerNum(d.femaleVillageLeaders)} នាក់</li>
              <li>១.៩. ចំនួនថ្នាក់ដឹកនាំភូមិជាយុវជន (ក្រោម៣៥ឆ្នាំ) {toKhmerNum(d.youthVillageLeaders)} នាក់</li>
            </ol>
          </td>
        </tr>
        <tr>
          <td className="border border-black text-center p-3 font-siemreap">១.២</td>
          <td className="border border-black p-3 font-siemreap" colSpan={2}>
            ការលើកកម្ពស់សិទ្ធិសេរីភាពរបស់ប្រជាពលរដ្ឋ
          </td>
        </tr>
        <tr>
          <td className="border border-black text-center align-top p-3 font-siemreap">១.២.១</td>
          <td className="border border-black p-3 font-siemreap">
            ករណីរំលោភសិទ្ធិ ជំនឿសាសនា សិទ្ធិមនុស្សពាក់ព័ន្ធនឹងការប្រកាន់ពូជសាសន៍ ពណ៌សម្បុរ ភេទ ភាសា និន្នាការនយោបាយ អតីតកាល ដើមកំណើតជាតិ ឋានៈសង្គម ធនធាន ឬស្ថានភាពផ្សេងទៀត
          </td>
          <td className="border border-black p-3 font-siemreap text-justify">
            ចំនួនករណីរំលោភសិទ្ធិមនុស្សពាក់ព័ន្ធនឹងការប្រកាន់ពូជសាសន៍ ពណ៌សម្បុរ ភេទ ភាសា ជំនឿ សាសនា និន្នាការនយោបាយ អតីតកាល ដើមកំណើតជាតិ ឋានៈសង្គម ធនធាន ឬ ស្ថានភាពផ្សេងទៀត {toKhmerNum(d.humanRightsViolations)}
          </td>
        </tr>
        <tr>
          <td className="border border-black text-center align-top p-3 font-siemreap">១.២.២</td>
          <td className="border border-black p-3 font-siemreap">
            ចំនួនប្រជាពលរដ្ឋ ដែលបានចូលរួមវេទិកាសាធារណៈរបស់ឃុំ សង្កាត់
          </td>
          <td className="border border-black p-3 font-siemreap text-justify">
            ចំនួនប្រជាពលរដ្ឋដែលបានចូលរួមវេទិកាសាធារណៈរបស់ឃុំ សង្កាត់ {toKhmerNum(d.publicForumParticipants)} នាក់
          </td>
        </tr>
        <tr>
          <td className="border border-black text-center align-top p-3 font-siemreap">១.២.៣</td>
          <td className="border border-black font-siemreap">
            <ol className="pl-5 space-y-1">
              <li>១. ចំនួនប្រជាពលរដ្ឋ ដែលបានចូលរួមកិច្ចប្រជុំក្រុមប្រឹក្សាឃុំ សង្កាត់</li>
              <li>២. ចំនួនប្រជាពលរដ្ឋចូលរួម ក្នុងដំណើរការរៀបចំផែនការអភិវឌ្ឍ និងកម្មវិធីវិនិយោគ ៣ឆ្នាំរំកិលរបស់ឃុំ សង្កាត់</li>
              <li>៣. ឃុំ សង្កាត់ដែលបានបង្កើតគណៈកម្មការគ្រប់គ្រងគម្រោងដែលមានការចូលរួមពីប្រជាពលរដ្ឋ (មាន ឬមិនមាន)</li>
            </ol>
          </td>
          <td className="border border-black font-siemreap pr-4 text-justify align-top">
            <ol className="pl-5 space-y-1">
              <li>១. ចំនួន {toKhmerNum(d.councilMeetingParticipants)} នាក់</li>
              <li>២. ចំនួន {toKhmerNum(d.planningProcessParticipants)} នាក់</li>
              <li>៣. 
                <label className="pl-5 inline-flex items-center gap-4 mr-4 cursor-not-allowed">
                  <input type="checkbox" disabled className="accent-blue-600" checked={d.hasProjectManagementCommittee === "មាន"} />
                  មាន
                </label>
                <label className="inline-flex items-center gap-4 cursor-not-allowed">
                  <input type="checkbox" disabled className="accent-blue-600" checked={d.hasProjectManagementCommittee === "មិនមាន"} />
                  មិនមាន
                </label>
              </li>
            </ol>
          </td>
        </tr>
        <tr>
          <td className="border border-black text-center align-top p-3 font-siemreap">១.២.៤</td>
          <td className="border border-black font-siemreap">
            <ol className="pl-5 space-y-1">
              <li>១. ចំនួនប្រជាពលរដ្ឋដែលបានទទួលសេវារដ្ឋបាល ឃុំ សង្កាត់</li>
              <li>២. ចំនួនគម្រោង (សេវាសង្គម និងហេដ្ឋារចនាសម្ព័ន្ធ) បានរៀបចំដោយឃុំ សង្កាត់</li>
            </ol>
          </td>
          <td className="border border-black font-siemreap pr-4 text-justify align-top">
            <ol className="pl-5 space-y-1">
              <li>១. ចំនួន {toKhmerNum(d.administrativeServiceRecipients)} នាក់</li>
              <li>២. ចំនួន {toKhmerNum(d.communityProjectsCount)} គម្រោង</li>
            </ol>
          </td>
        </tr>
        <tr>
          <td className="border border-black text-center align-top p-3 font-siemreap">១.២.៥</td>
          <td className="border border-black font-siemreap">
            <ol className="pl-5 space-y-1">
              <li>១. សំណើ សំណូមពរ ក្តីកង្វល់ និងបញ្ហាប្រឈមនានារបស់ប្រជាពលរដ្ឋពាក់ព័ន្ធនឹងការផ្តល់សេវា</li>
              <li>២. ការសម្របសម្រួលដោះស្រាយសំណើ សំណូមពរ ក្តីកង្វល់ និងបញ្ហាប្រឈមនានា</li>
            </ol>
          </td>
          <td className="border border-black font-siemreap pr-4 text-justify align-top">
            <ol className="pl-5 space-y-1">
              <li>១. ចំនួន {toKhmerNum(d.serviceRequestCases)} ករណី</li>
              <li>២. ចំនួន {toKhmerNum(d.serviceResolvedCases)} ករណី</li>
            </ol>
          </td>
        </tr>
        <tr>
          <td className="border border-black text-center align-top p-3 font-siemreap">១.៣</td>
          <td colSpan={2} className="border border-black p-3 font-siemreap">
            ភាពសុខដុមរមនាក្នុងសង្គម
          </td>
        </tr>
        <tr>
          <td className="border border-black text-center align-top p-3 font-siemreap">១.៣.១</td>
          <td className="border border-black font-siemreap">
            <ol className="pl-5 space-y-1">
              <li>១. វិវាទពាក់ព័ន្ធនឹងជំនឿ ប្រពៃណី និងសាសនាផ្សេងៗគ្នានៅមូលដ្ឋាន</li>
            </ol>
          </td>
          <td className="border border-black font-siemreap pr-4 text-justify align-top">
            <ol className="pl-5 space-y-1">
              <li>១. ចំនួន {toKhmerNum(d.religiousDisputeCases)} ករណី</li>
            </ol>
          </td>
        </tr>
        <tr>
          <td className="border border-black text-center align-top p-3 font-siemreap">១.៣.២</td>
          <td className="border border-black font-siemreap">
            <ol className="pl-5 space-y-1">
              <li>១. ករណីវិវាទរវាងប្រជាពលរដ្ឋនិងប្រជាពលរដ្ឋពាក់ព័ន្ធនឹងនិន្នាការនយោបាយ</li>
            </ol>
          </td>
          <td className="border border-black font-siemreap pr-4 text-justify align-top">
            <ol className="pl-5 space-y-1">
              <li>១. ចំនួន {toKhmerNum(d.politicalDisputeCases)} ករណី</li>
            </ol>
          </td>
        </tr>
        <tr>
          <td className="border border-black text-center align-top p-3 font-siemreap">១.៣.៣</td>
          <td className="border border-black font-siemreap p-3">
            ឃុំ សង្កាត់ដែលមានមណ្ឌល ទីធ្លាសាធារណៈ ឬអគារវប្បធម៌ក្នុងសហគមន៍ដែលសាធារណជនអាចមានការជួបជុំ ការសម្តែង និងការចែករំលែកនូវសិល្បៈ ប្រពៃណី ទំនៀមទម្លាប់ សាសនា និងចំណេះដឹងផ្សេងៗ
          </td>
          <td className="border border-black pl-5 pr-4 font-siemreap text-justify align-top">
            <label className="inline-flex items-center gap-4 mr-4 cursor-not-allowed">
              <input type="checkbox" disabled className="accent-blue-600" checked={d.hasCommunityCulturalSpace === "មាន"} />
              មាន
            </label>
            <label className="inline-flex items-center gap-4 cursor-not-allowed">
              <input type="checkbox" disabled className="accent-blue-600" checked={d.hasCommunityCulturalSpace === "គ្មាន"} />
              គ្មាន
            </label>
          </td>
        </tr>
      </tbody>
    </table>
  );
}